import sys
import json
import os
import requests
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI
from langchain.callbacks import get_openai_callback

load_dotenv()

azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_DEPLOYMENT_NAME": os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
    }
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

st.title("Agent and function calling demo")

with st.sidebar:
    os.environ["AZURE_OPENAI_ENDPOINT"] = azure_config["AZURE_OPENAI_ENDPOINT"]
    
def generate_response(input_text):
    
    client = AzureOpenAI(
        api_key=azure_config["AZURE_OPENAI_API_KEY"],
        api_version=azure_config["AZURE_OPENAI_API_VERSION"],
        azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
    )
    
    functions=[
        {
            "name":"get_weather",
            "description":"Retrieve real-time weather information/data about a particular location/place",
            "parameters":{
                "type":"object",
                "properties":{
                    "location":{
                        "type":"string",
                        "description":"the exact location whose real-time weather is to be determined",
                    },
                    
                },
                "required":["location"]
            },
        }
    ] 

    with st.spinner('Processing...'):
        initial_response = client.chat.completions.create(
            model="gpt-35-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": input_text}
            ],
            functions=functions
        )
        if (initial_response.choices[0].finish_reason == 'function_call'):
            function_name = initial_response.choices[0].message.function_call.name
            function_argument = json.loads(initial_response.choices[0].message.function_call.arguments)
            location= function_argument['location']
            if(location):
                resp=getattr(sys.modules[__name__], function_name)(location)
        else:
            resp=initial_response.choices[0].message.content

    #st.success('Done')
    #print (initial_response)

    with get_openai_callback() as cb:
        st.info(resp)
#        for line in weather_result.splitlines():
#            st.info(line) # chat model output
        st.info(cb) # callback output (like cost)

def get_weather(location):
   #calling open weather map API for information retrieval
   #fetching latitude and longitude of the specific location respectively
    print ("get weather function called. Parameter passed: ", location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location+"&limit=1&appid=" + OPENWEATHERMAP_API_KEY
    response=requests.get(url)
    get_response=response.json()
    latitude=get_response[0]['lat']
    longitude = get_response[0]['lon']

    url_final = "https://api.openweathermap.org/data/2.5/weather?lat=" + str(latitude) + "&lon=" + str(longitude) + "&appid=" + OPENWEATHERMAP_API_KEY
    final_response = requests.get(url_final)
    final_response_json = final_response.json()
    weather=final_response_json['weather'][0]['description']
    return weather

with st.form("my_form"):
    text = st.text_area("Enter text:", "What's the weather in Mumbai today?")
    submitted = st.form_submit_button("Submit")
    generate_response(text)