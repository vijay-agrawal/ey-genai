import sys
import json
import os
import requests
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI
from langchain.callbacks import get_openai_callback

# Load environment variables
load_dotenv()

# Configure Azure OpenAI settings
azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
}
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

# App title
st.title("Weather Assistant - Umbrella Advisor")
st.markdown("Ask me if you should carry an umbrella tomorrow!")

# Initialize chat history in session state if it doesn't exist
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Function to get weather data
def get_weather(location):
    print(f"Getting weather for location: {location}")
    
    # Get latitude and longitude from location name
    geo_url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={OPENWEATHERMAP_API_KEY}"
    geo_response = requests.get(geo_url)
    
    if geo_response.status_code != 200:
        return f"Error: Could not retrieve location data. Status code: {geo_response.status_code}"
    
    geo_data = geo_response.json()
    if not geo_data:
        return f"Error: Location '{location}' not found."
    
    latitude = geo_data[0]['lat']
    longitude = geo_data[0]['lon']
    
    # Get current weather data
    weather_url = f"http://api.openweathermap.org/data/2.5/forecast?lat={latitude}&lon={longitude}&appid={OPENWEATHERMAP_API_KEY}&units=metric"
    weather_response = requests.get(weather_url)
    
    if weather_response.status_code != 200:
        return f"Error: Could not retrieve weather data. Status code: {weather_response.status_code}"
    
    weather_data = weather_response.json()
    
    # Extract tomorrow's weather data (assuming forecast entries are in 3-hour intervals)
    tomorrow_forecasts = []
    for forecast in weather_data['list'][:8]:  # First 24 hours (8 entries of 3 hours each)
        forecast_time = forecast['dt_txt']
        description = forecast['weather'][0]['description']
        rain_probability = forecast.get('pop', 0) * 100  # Probability of precipitation
        
        tomorrow_forecasts.append({
            'time': forecast_time,
            'description': description,
            'rain_probability': rain_probability,
            'temp': forecast['main']['temp']
        })
    
    # Return formatted weather data
    return {
        'location': location,
        'forecast': tomorrow_forecasts,
        'raw_data': json.dumps(weather_data, indent=2)
    }

# Function to generate response using Azure OpenAI
def generate_response(input_text):
    client = AzureOpenAI(
        api_key=azure_config["AZURE_OPENAI_API_KEY"],
        api_version=azure_config["AZURE_OPENAI_API_VERSION"],
        azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
    )
    
    # Define function schema for the model
    functions = [
        {
            "name": "get_weather",
            "description": "Retrieve weather forecast for tomorrow for a specific location",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {
                        "type": "string",
                        "description": "The city or location to get weather information for",
                    },
                },
                "required": ["location"]
            },
        }
    ]
    
    # ReAct system prompt
    system_prompt = """
    You are an intelligent weather assistant that helps users decide if they should carry an umbrella tomorrow.
    Follow a ReAct-based approach to reason about the weather before responding.

    Steps to follow:
    1. Identify if the user has mentioned a location. 
       - If no location is provided, ask the user to specify one.
    2. Retrieve the weather forecast for the given location.
    3. Based on the forecast, decide whether carrying an umbrella is necessary.
       - Consider rain probability, weather descriptions like "rain", "drizzle", "shower", etc.
       - If any period tomorrow has >30% chance of rain or contains rain-related terms, recommend an umbrella.
    4. Explain your reasoning in a natural, conversational manner.

    Example Responses:
    - "You do not need to carry an umbrella tomorrow as the weather in {location} is sunny with only a 5% chance of precipitation."
    - "Yes, you should carry an umbrella as there is a high chance of rain in {location} tomorrow afternoon, with a 60% probability of precipitation."

    Always provide your reasoning based on the actual forecast data.
    """
    
    # First API call to determine if we need to call a function
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": input_text}
    ]
    
    # Add chat history for context
    for msg in st.session_state.messages[-4:]:  # Include up to last 4 messages for context
        messages.append({"role": msg["role"], "content": msg["content"]})
    
    # Make initial completion call to determine if we need weather data
    initial_response = client.chat.completions.create(
        model=azure_config["AZURE_OPENAI_MODEL_NAME"],
        messages=messages,
        functions=functions,
        temperature=0.7
    )
    
    # Check if the model wants to call a function
    if initial_response.choices[0].finish_reason == 'function_call':
        function_call = initial_response.choices[0].message.function_call
        function_name = function_call.name
        
        # Parse function arguments
        function_args = json.loads(function_call.arguments)
        location = function_args.get('location')
        
        if not location:
            # If model identified we need location but couldn't find it
            return "I'd be happy to help! To check if you need an umbrella tomorrow, could you please tell me your location?"
        
        # Call the weather API
        weather_data = get_weather(location)
        
        # Format weather data for the model
        if isinstance(weather_data, str) and "Error" in weather_data:
            # Handle API errors
            return f"I'm sorry, I couldn't get the weather information: {weather_data}"
        
        # Prepare a summary of tomorrow's weather
        weather_summary = f"Weather forecast for {weather_data['location']} for tomorrow:\n\n"
        rain_conditions = False
        max_rain_probability = 0
        
        for forecast in weather_data['forecast']:
            weather_summary += f"- {forecast['time']}: {forecast['description'].capitalize()}, {forecast['temp']}°C, Rain probability: {forecast['rain_probability']}%\n"
            
            # Check if any rain-related terms are in the description
            rain_terms = ["rain", "shower", "drizzle", "storm", "precipitation", "thunderstorm"]
            if any(term in forecast['description'].lower() for term in rain_terms) or forecast['rain_probability'] > 30:
                rain_conditions = True
            
            max_rain_probability = max(max_rain_probability, forecast['rain_probability'])
        
        # Add the function result to messages
        messages.append({
            "role": "function",
            "name": function_name,
            "content": weather_summary
        })
        
        # Make a final completion call with the weather data
        final_response = client.chat.completions.create(
            model=azure_config["AZURE_OPENAI_MODEL_NAME"],
            messages=messages,
            temperature=0.7
        )
        
        response = final_response.choices[0].message.content
    else:
        # Model didn't call function, maybe asking for location
        response = initial_response.choices[0].message.content
    
    return response

# User input via chat interface
if prompt := st.chat_input("Type your question here..."):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Display user message
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Generate and display response
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response = generate_response(prompt)
            st.markdown(response)
    
    # Add assistant response to chat history
    st.session_state.messages.append({"role": "assistant", "content": response})

# Sidebar with app information
with st.sidebar:
    st.header("About")
    st.markdown("""
    This Weather Assistant uses:
    - Azure OpenAI for reasoning
    - OpenWeatherMap API for real-time weather data
    - ReAct approach for planning and execution
    
    Ask if you should carry an umbrella tomorrow!
    """)
    
    st.subheader("Sample Questions")
    st.markdown("""
    - Should I bring an umbrella tomorrow?
    - Will it rain tomorrow in Seattle?
    - Do I need an umbrella in London tomorrow?
    """)

# hf token: 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
