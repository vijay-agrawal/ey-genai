import openai
from crew import Crew, Worker, Chat

###############################################################################
# 1. Configure Azure OpenAI
###############################################################################
openai.api_type = "azure"
openai.api_base = "https://YOUR_AZURE_OPENAI_ENDPOINT.openai.azure.com"
openai.api_version = "2023-03-15-preview"  # or the version your endpoint supports
openai.api_key = "YOUR_AZURE_OPENAI_API_KEY"


###############################################################################
# 2. Create Worker classes
###############################################################################
class DiseaseTreatmentResearchWorker(Worker):
    """
    Fetches or constructs news items about disease treatments/research.
    """
    def __init__(self, disease: str):
        super().__init__()
        self.disease = disease

    def do_work(self, *args, **kwargs):
        # In practice, call an external news API.
        # For demo purposes, return a static list:
        return [
            f"New clinical trial shows promise for {self.disease} treatment.",
            f"Breakthrough study on gene therapy for {self.disease} was published."
        ]


class MedicationWorker(Worker):
    """
    Fetches or constructs news items about medications/drugs.
    """
    def __init__(self, disease: str):
        super().__init__()
        self.disease = disease

    def do_work(self, *args, **kwargs):
        # In practice, call an external news API.
        # For demo purposes, return a static list:
        return [
            f"FDA approves new drug for {self.disease}.",
            f"Guidelines updated for prescribing {self.disease} medication."
        ]


class SummarizationWorker(Worker):
    """
    Uses Azure OpenAI to summarize the combined news items.
    """
    def __init__(self, disease: str, research_items, medication_items):
        super().__init__()
        self.disease = disease
        self.research_items = research_items
        self.medication_items = medication_items

    def do_work(self, *args, **kwargs):
        # Create a Chat instance from crew
        chat = Chat(
            system="You are a helpful AI assistant specializing in summarizing healthcare news.",
            openai_config={
                "api_type": "azure",
                "api_base": openai.api_base,
                "api_version": openai.api_version,
                "api_key": openai.api_key
            },
            deployment_id="YOUR_MODEL_DEPLOYMENT_NAME"  # e.g. "gpt-35-turbo"
        )

        # Prompt the model to summarize
        user_prompt = f"""
Summarize these latest news items about {self.disease}:

Treatment / Research:
{self.research_items}

Medications / Drugs:
{self.medication_items}

Format your response as a short paragraph.
"""
        response = chat.ask(user_prompt)
        return response


###############################################################################
# 3. Orchestrate with Crew
###############################################################################
def get_healthcare_news_for_disease(disease: str):
    """
    Orchestrates workers to:
      1) Collect disease news
      2) Summarize them with the LLM
    """
    # Create a Crew to run parallel tasks
    crew = Crew()

    # Add "fetch" workers
    research_worker = DiseaseTreatmentResearchWorker(disease)
    medication_worker = MedicationWorker(disease)

    # Run them in parallel
    crew.add(research_worker)
    crew.add(medication_worker)
    crew.run()

    # Retrieve results
    research_items = research_worker.result
    medication_items = medication_worker.result

    # Summarization occurs after data is fetched
    summarizer = SummarizationWorker(disease, research_items, medication_items)
    summarizer.run()

    # Return both raw and summarized results
    return {
        "raw_news": {
            "treatment_research": research_items,
            "medication_news": medication_items
        },
        "summary": summarizer.result
    }


###############################################################################
# 4. Example Usage
###############################################################################
if __name__ == "__main__":
    user_disease = "diabetes"  # e.g., from user input
    news_output = get_healthcare_news_for_disease(user_disease)

    print("==== RAW NEWS ====")
    for category, articles in news_output["raw_news"].items():
        print(f"\n--- {category.upper()} ---")
        for article in articles:
            print("*", article)

    print("\n==== LLM SUMMARY ====")
    print(news_output["summary"])
