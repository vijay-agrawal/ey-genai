# CrewAI Agentic Design Pattern Demos

These 5 minimal demos show popular agentic AI patterns with [CrewAI](https://pypi.org/project/crewai/).
They are small, self-contained, and oriented to real-world domains (BFSI, healthcare, retail, telco, manufacturing).

> **Prereqs**
> - Python 3.10+
> - `pip install -r requirements.txt`
> - Set your LLM key (OpenAI shown as example): `export OPENAI_API_KEY=...` (or use a `.env` file)

## Demos
1. **Supervisor–Worker (BFSI)**: `python demos/bfs_credit_risk.py`
2. **Critic–Author / Reflexion (Healthcare)**: `python demos/healthcare_reflexion.py`
3. **ReWOO / Tool-Orchestration (Retail)**: `python demos/retail_rewoo.py`
4. **Memory + State (Telco Support)**: `python demos/telco_memory_state.py`
5. **Pipeline / Assembly Line (Manufacturing Quality)**: `python demos/manufacturing_pipeline.py`

Each script prints a short report to the console and also writes an output file in `outputs/`.

## Environment
- You can configure the model in each script via env vars (defaults work with OpenAI-compatible APIs):
  - `MODEL_NAME` (default: `gpt-4o-mini`)
  - `OPENAI_API_BASE` (optional for OpenAI-compatible endpoints)
  - `OPENAI_API_KEY` (required unless you swap in a local model/provider)

## Structure
```
crewai-pattern-demos/
  README.md
  requirements.txt
  .env.example
  demos/
    bfs_credit_risk.py
    healthcare_reflexion.py
    retail_rewoo.py
    telco_memory_state.py
    manufacturing_pipeline.py
  data/
    credit_applications.csv
    clinical_notes.txt
    retail_prices.csv
    telco_tickets.jsonl
    manufacturing_defects.csv
  outputs/  (created at runtime)
```

## Notes
- These examples avoid network calls (no external web/search). Tools read the local sample data.
- Swap tools or add your own (e.g., web search, SQL, vector DB) to scale up realism.
- If you use a local LLM, set `OPENAI_API_BASE` to your compatible gateway and keep the same API.
