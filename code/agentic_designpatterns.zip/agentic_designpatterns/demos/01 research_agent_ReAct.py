import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import SerpApiTool, FileReadTool, CalculatorTool, WebsiteSearchTool
from typing import Dict, Any
import json

# Set up environment variables (you'll need to set these)
# os.environ["SERP_API_KEY"] = "your_serp_api_key_here"
# os.environ["OPENAI_API_KEY"] = "your_openai_api_key_here"

class MathCalculator:
    """Custom calculator tool for mathematical operations"""
    
    def __init__(self):
        self.name = "calculator"
        self.description = "Performs mathematical calculations. Input should be a mathematical expression as a string."
    
    def __call__(self, expression: str) -> str:
        """Safely evaluate mathematical expressions"""
        try:
            # Remove any potentially dangerous operations
            safe_chars = set('0123456789+-*/().,** ')
            if not all(c in safe_chars for c in expression.replace(' ', '')):
                return f"Error: Invalid characters in expression: {expression}"
            
            # Evaluate the expression
            result = eval(expression)
            return f"Result: {result}"
        except Exception as e:
            return f"Error calculating '{expression}': {str(e)}"

class DataAnalyzer:
    """Custom tool for basic data analysis operations"""
    
    def __init__(self):
        self.name = "data_analyzer"
        self.description = "Analyzes data patterns, calculates statistics, or processes structured data."
    
    def __call__(self, data_description: str) -> str:
        """Analyze data based on description"""
        # This is a simplified example - in practice, you'd implement actual data analysis
        analysis_types = {
            "average": "calculated mean value",
            "trend": "identified upward/downward trend",
            "correlation": "found statistical relationship",
            "summary": "provided statistical summary"
        }
        
        for analysis_type, result in analysis_types.items():
            if analysis_type in data_description.lower():
                return f"Analysis complete: {result} for {data_description}"
        
        return f"General analysis performed on: {data_description}"

def create_react_agent(model: str = "gpt-4o-mini") -> Agent:
    """Create a ReAct agent with comprehensive tools"""
    
    # Initialize tools
    search_tool = SerpApiTool()
    calculator = MathCalculator()
    data_analyzer = DataAnalyzer()
    file_reader = FileReadTool()
    
    # Define the ReAct agent
    react_agent = Agent(
        role="ReAct Research Assistant",
        goal=(
            "Answer complex questions by systematically thinking through problems, "
            "using appropriate tools iteratively, and providing well-reasoned final answers."
        ),
        backstory=(
            "You are an intelligent research assistant that follows the ReAct (Reasoning + Acting) "
            "methodology. You break down complex problems into steps, use tools strategically, "
            "and always cite your sources. You're methodical, accurate, and transparent about "
            "your reasoning process."
        ),
        tools=[search_tool, calculator, data_analyzer, file_reader],
        allow_delegation=False,
        verbose=True,
        model=model,
        max_iter=10,  # Limit iterations to prevent infinite loops
    )
    
    return react_agent

def create_react_task(question: str) -> Task:
    """Create a ReAct task for a specific question"""
    
    task_description = f"""
    Answer this question using the ReAct methodology: "{question}"
    
    Follow this structured approach:
    
    **THINK**: Analyze the question and plan your approach
    - What information do I need?
    - Which tools might be helpful?
    - What's my strategy?
    
    **ACT**: Use exactly one tool with specific, minimal parameters
    - Choose the most appropriate tool for the current step
    - Use clear, focused inputs
    
    **OBSERVE**: Analyze the tool results
    - What did I learn?
    - Is this information sufficient?
    - What should I do next?
    
    **REPEAT**: Continue the THINK-ACT-OBSERVE cycle until you have enough information
    
    **FINAL ANSWER**: Provide a comprehensive answer that includes:
    - Direct answer to the question
    - Brief rationale explaining your reasoning
    - Citations and sources used
    - Confidence level in your answer
    
    Rules:
    - Be concise in each step
    - Avoid redundant tool calls
    - Stop when you're confident in your answer
    - Always cite sources when available
    - If uncertain, acknowledge limitations
    """
    
    task = Task(
        description=task_description,
        expected_output=(
            "A structured final answer containing: "
            "1) Direct answer to the question, "
            "2) Brief rationale and reasoning process, "
            "3) Sources and references used, "
            "4) Confidence assessment"
        )
    )
    
    return task

def run_react_query(question: str, model: str = "gpt-4o-mini") -> str:
    """Run a complete ReAct query"""
    
    print(f"🤔 Processing question: {question}")
    print("=" * 50)
    
    # Create agent and task
    agent = create_react_agent(model)
    task = create_react_task(question)
    
    # Create and run crew
    crew = Crew(
        agents=[agent],
        tasks=[task],
        process=Process.sequential,
        verbose=True
    )
    
    result = crew.kickoff()
    return result

# Example usage and test cases
if __name__ == "__main__":
    
    # Example 1: Mathematical reasoning
    print("🧮 Example 1: Mathematical Problem")
    print("-" * 30)
    math_question = "If a company's revenue grew from $1.2 million to $1.8 million, what was the percentage increase?"
    
    try:
        result1 = run_react_query(math_question)
        print(f"Result: {result1}\n")
    except Exception as e:
        print(f"Error: {e}\n")
    
    # Example 2: Research question
    print("🔍 Example 2: Research Question")
    print("-" * 30)
    research_question = "What are the current trends in renewable energy adoption globally?"
    
    try:
        result2 = run_react_query(research_question)
        print(f"Result: {result2}\n")
    except Exception as e:
        print(f"Error: {e}\n")
    
    # Example 3: Multi-step analysis
    print("📊 Example 3: Multi-step Analysis")
    print("-" * 30)
    analysis_question = "Compare the market capitalization of the top 3 tech companies and calculate the average"
    
    try:
        result3 = run_react_query(analysis_question)
        print(f"Result: {result3}\n")
    except Exception as e:
        print(f"Error: {e}\n")

# Alternative: Interactive mode
def interactive_react_session():
    """Run an interactive ReAct session"""
    
    print("🤖 Welcome to Interactive ReAct Agent!")
    print("Ask any question and I'll use ReAct methodology to answer it.")
    print("Type 'quit' to exit.\n")
    
    while True:
        question = input("❓ Your question: ").strip()
        
        if question.lower() in ['quit', 'exit', 'q']:
            print("👋 Goodbye!")
            break
        
        if not question:
            continue
        
        try:
            result = run_react_query(question)
            print(f"\n✅ Answer: {result}\n")
            print("-" * 50)
        except Exception as e:
            print(f"❌ Error: {e}\n")

# Usage examples for different scenarios
def demonstrate_use_cases():
    """Show various use cases for the ReAct agent"""
    
    use_cases = [
        {
            "category": "Financial Analysis",
            "questions": [
                "Calculate the compound annual growth rate for an investment that grew from $10,000 to $15,000 over 3 years",
                "What's the current price of Bitcoin and how has it changed in the last month?",
                "Compare the P/E ratios of Apple, Microsoft, and Google"
            ]
        },
        {
            "category": "Market Research", 
            "questions": [
                "What are the latest developments in artificial intelligence in 2024?",
                "Find information about the top 5 fastest-growing startups in fintech",
                "What are the current trends in electric vehicle sales globally?"
            ]
        },
        {
            "category": "Scientific Inquiry",
            "questions": [
                "What's the latest research on climate change impacts on ocean temperatures?",
                "Explain the recent breakthrough in quantum computing and its implications",
                "What are the side effects and efficacy rates of the latest COVID-19 vaccines?"
            ]
        },
        {
            "category": "Business Intelligence",
            "questions": [
                "Analyze the competitive landscape in the cloud computing industry",
                "What are the key success factors for SaaS companies in 2024?",
                "Compare the business models of Netflix, Disney+, and Amazon Prime"
            ]
        }
    ]
    
    print("🎯 ReAct Agent Use Cases")
    print("=" * 50)
    
    for use_case in use_cases:
        print(f"\n📁 {use_case['category']}")
        print("-" * len(use_case['category']))
        for i, question in enumerate(use_case['questions'], 1):
            print(f"{i}. {question}")
    
    print(f"\n💡 To run any of these examples:")
    print(f"   result = run_react_query('your_question_here')")

# Uncomment to run demonstrations
# demonstrate_use_cases()
interactive_react_session()