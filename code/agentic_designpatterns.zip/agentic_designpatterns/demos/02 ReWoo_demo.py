#!/usr/bin/env python3
import os, pandas as pd
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from textwrap import dedent

"""
ReWoo PATTERN EXPLANATION:
ReWoo stands for "Reasoning without Observation" - a three-stage approach:

1. REASONING (R): Plan what needs to be done
   - Break down complex problems into steps
   - Create a logical workflow without executing actions

2. WORKING (W): Execute the planned actions
   - Use tools and APIs to gather information
   - Perform calculations and data processing
   - Implement the reasoning plan

3. OBSERVING (O): Evaluate results and provide feedback
   - Analyze the outcomes of executed actions
   - Identify issues or improvements needed
   - Provide recommendations for optimization

This pattern separates planning from execution, making workflows more reliable.
"""

"""
ReWoo EXECUTION FLOW:

STAGE 1 - REASONING:
- Planner analyzes the inventory optimization problem
- Creates step-by-step plan considering:
  * Current stock levels
  * Seasonal demand patterns
  * Supplier constraints
  * Timeline requirements
- Output: Detailed action plan

STAGE 2 - WORKING:
- Executor takes the plan and implements each step
- Uses tools to:
  * Check current stock levels
  * Forecast demand for winter jackets
  * Get supplier delivery information
- Gathers real data according to the plan
- Output: Execution results with actual data

STAGE 3 - OBSERVING:
- Observer analyzes the execution results
- Compares planned vs actual outcomes
- Identifies performance gaps or optimization opportunities
- Provides recommendations for improvement
- Output: Performance analysis and next steps

BENEFITS OF ReWoo PATTERN:
- Separation of concerns (plan vs execute vs evaluate)
- More reliable execution through upfront planning
- Built-in feedback loop for continuous improvement
- Easier debugging (can isolate issues to specific stages)
- Scalable (can add more specialized agents to each stage)
"""


load_dotenv()
MODEL = os.getenv("MODEL_NAME","gpt-4o-mini")

def load_prices():
    return pd.read_csv("data/retail_prices.csv")

planner = Agent(
    role="Retail Pricing Planner",
    goal="Produce a symbolic plan (operations) to recommend price changes for top 3 SKUs.",
    backstory="Retail strategist who outlines exact tool I/O needed.",
    model=MODEL
)

operator = Agent(
    role="Tool Operator",
    goal="Execute the plan strictly via local tools and report computed metrics.",
    backstory="Trusts data over hunches, returns small data tables from Python tools.",
    model=MODEL
)

finalizer = Agent(
    role="Pricing Finalizer",
    goal="Synthesize a final price recommendation with rationale and projected impact.",
    backstory="Converts tool outputs into an executive note with actionables.",
    model=MODEL
)

task1 = Task(
    description=dedent("""\
    ReWOO step 1 — Produce a plan with explicit operations:
    - OP1: Load retail_prices.csv
    - OP2: Compute price gap = (competitor_price - price)
    - OP3: Propose +/- price deltas to balance margin and competitiveness
    Return only the plan and I/O names (no narrative).
    """),
    agent=planner
)

task2 = Task(
    description=dedent("""\
    Execute the plan using the local tools and return a small table with:
    sku, product, price, competitor_price, gap, proposed_price, rationale (1 line).
    """),
    agent=operator
)

task3 = Task(
    description=dedent("""\
    Using the operator's table, write a concise recommendation (<=150 words):
    - Highlight risks (race to bottom, inventory effects)
    - Include an 'Experiment plan' (A/B for 7 days)
    """),
    agent=finalizer
)

crew = Crew(agents=[planner, operator, finalizer], tasks=[task1, task2, task3], process=Process.sequential)

if __name__ == "__main__":
    df = load_prices().copy()
    df["gap"] = (df["competitor_price"] - df["price"]).round(2)
    # generate a tiny "operator tool" output for the model to read
    df["proposed_price"] = (df["price"] + df["gap"].clip(-2,2)/2).round(2)
    df["rationale"] = ["Close gap modestly to test"]*len(df)
    table = df[["sku","product","price","competitor_price","gap","proposed_price","rationale"]].to_markdown(index=False)
    task2.context = [table]
    result = crew.kickoff()
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/retail_rewoo_pricing.md","w") as f: f.write(str(result))
    print("=== Retail ReWOO / Tool-Orchestration Result ===")
    print(result)
