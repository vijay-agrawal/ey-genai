import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import SerpApiTool, FileReadTool, WebsiteSearchTool
from typing import Dict, Any, List, Tuple
import json
import re

# Set up environment variables (you'll need to set these)
# os.environ["SERP_API_KEY"] = "your_serp_api_key_here"
# os.environ["OPENAI_API_KEY"] = "your_openai_api_key_here"

class MathCalculator:
    """Calculator tool for mathematical operations"""
    
    def __init__(self):
        self.name = "calculator"
        self.description = "Performs mathematical calculations. Input should be a mathematical expression."
    
    def __call__(self, expression: str) -> str:
        try:
            # Safe evaluation of mathematical expressions
            safe_chars = set('0123456789+-*/().,** ')
            if not all(c in safe_chars for c in expression.replace(' ', '')):
                return f"Error: Invalid characters in expression: {expression}"
            
            result = eval(expression)
            return f"Result: {result}"
        except Exception as e:
            return f"Error calculating '{expression}': {str(e)}"

class DataProcessor:
    """Tool for data processing and analysis"""
    
    def __init__(self):
        self.name = "data_processor"
        self.description = "Processes and analyzes data, computes statistics, finds patterns."
    
    def __call__(self, operation: str) -> str:
        operations = {
            "average": "Calculated mean value from provided data",
            "sum": "Calculated total sum of values",
            "max": "Found maximum value",
            "min": "Found minimum value",
            "trend": "Analyzed trend pattern",
            "correlation": "Computed correlation coefficient",
            "percentage": "Calculated percentage change"
        }
        
        for op, result in operations.items():
            if op in operation.lower():
                return f"Data processing complete: {result}"
        
        return f"Processed data operation: {operation}"

class ReWOOPlanner:
    """Planner agent that creates execution plans without tool observation"""
    
    @staticmethod
    def create_planner_agent(model: str = "gpt-4o-mini") -> Agent:
        return Agent(
            role="ReWOO Planner",
            goal="Create detailed, step-by-step execution plans for complex questions without executing tools.",
            backstory=(
                "You are a strategic planner that specializes in the ReWOO methodology. "
                "You break down complex questions into logical sequences of tool calls, "
                "creating variables for intermediate results, and designing comprehensive plans "
                "without actually executing any tools. Your plans are detailed blueprints for execution."
            ),
            allow_delegation=False,
            verbose=True,
            model=model
        )
    
    @staticmethod
    def create_planning_task(question: str) -> Task:
        return Task(
            description=f"""
            Create a comprehensive execution plan for this question: "{question}"
            
            Follow the ReWOO planning methodology:
            
            **STEP 1: QUESTION ANALYSIS**
            - Identify the main question and sub-questions
            - Determine what information is needed
            - Identify the final output format required
            
            **STEP 2: TOOL MAPPING**
            Available tools:
            - search: For web searches and current information
            - calculator: For mathematical calculations
            - data_processor: For data analysis and statistics
            - file_reader: For reading files
            
            **STEP 3: CREATE EXECUTION PLAN**
            Create a numbered sequence of tool calls with:
            - Tool name and specific parameters
            - Variable assignments for results (e.g., #E1, #E2, #E3...)
            - Dependencies between steps
            - Expected output format
            
            **STEP 4: VARIABLE DEPENDENCIES**
            - Show how results from one step feed into the next
            - Create a dependency map
            
            Format your plan as:
            Plan: [Tool1(params) -> #E1, Tool2(#E1, params) -> #E2, ...]
            Dependencies: [#E1 -> #E2 -> #E3 -> Final Answer]
            
            Rules:
            - Do NOT execute any tools
            - Create specific, actionable steps
            - Use variable notation (#E1, #E2, etc.)
            - Plan for error handling
            - Minimize redundant steps
            """,
            expected_output=(
                "A detailed execution plan with: "
                "1) Step-by-step tool sequence with variables, "
                "2) Clear dependencies between steps, "
                "3) Expected outputs, "
                "4) Error handling considerations"
            )
        )

class ReWOOWorker:
    """Worker agent that executes the planned tool sequence"""
    
    @staticmethod
    def create_worker_agent(model: str = "gpt-4o-mini") -> Agent:
        search_tool = SerpApiTool()
        calculator = MathCalculator()
        data_processor = DataProcessor()
        file_reader = FileReadTool()
        
        return Agent(
            role="ReWOO Worker",
            goal="Execute the planned sequence of tool calls precisely and collect results.",
            backstory=(
                "You are a methodical executor that follows ReWOO execution plans. "
                "You execute each planned tool call in order, store results in variables, "
                "and pass information between steps as specified. You are precise, "
                "systematic, and handle errors gracefully."
            ),
            tools=[search_tool, calculator, data_processor, file_reader],
            allow_delegation=False,
            verbose=True,
            model=model
        )
    
    @staticmethod
    def create_execution_task(plan: str, question: str) -> Task:
        return Task(
            description=f"""
            Execute this ReWOO plan for the question: "{question}"
            
            **EXECUTION PLAN TO FOLLOW:**
            {plan}
            
            **EXECUTION INSTRUCTIONS:**
            
            1. **Parse the Plan**: Extract each tool call and variable assignment
            
            2. **Execute Sequentially**: 
               - Follow the exact sequence specified
               - Store each result in the designated variable (#E1, #E2, etc.)
               - Use previous results as inputs for subsequent steps
            
            3. **Variable Management**:
               - Clearly track what each variable contains
               - Substitute variables with actual values when needed
               - Maintain a result log
            
            4. **Error Handling**:
               - If a tool call fails, note the error and try alternatives
               - Continue execution where possible
               - Report any step failures clearly
            
            5. **Result Collection**:
               - Collect all intermediate results
               - Prepare data for the solver agent
            
            Do NOT provide final answers - only execute tools and collect results.
            """,
            expected_output=(
                "Execution results containing: "
                "1) Results from each planned tool call, "
                "2) Variable assignments and values, "
                "3) Any errors encountered, "
                "4) All collected information for final synthesis"
            )
        )

class ReWOOSolver:
    """Solver agent that synthesizes results into final answers"""
    
    @staticmethod
    def create_solver_agent(model: str = "gpt-4o-mini") -> Agent:
        return Agent(
            role="ReWOO Solver",
            goal="Synthesize execution results into comprehensive, well-reasoned final answers.",
            backstory=(
                "You are a synthesis expert that takes execution results from ReWOO workers "
                "and creates comprehensive final answers. You analyze all collected information, "
                "identify patterns, resolve conflicts, and provide well-reasoned conclusions "
                "with proper citations and confidence assessments."
            ),
            allow_delegation=False,
            verbose=True,
            model=model
        )
    
    @staticmethod
    def create_solving_task(execution_results: str, original_question: str) -> Task:
        return Task(
            description=f"""
            Synthesize these execution results into a final answer for: "{original_question}"
            
            **EXECUTION RESULTS:**
            {execution_results}
            
            **SYNTHESIS INSTRUCTIONS:**
            
            1. **Analyze Results**: Review all collected information systematically
            
            2. **Identify Key Findings**: Extract the most relevant information
            
            3. **Resolve Conflicts**: If there are contradictory results, explain why
            
            4. **Synthesize Answer**: Create a comprehensive response that:
               - Directly answers the original question
               - Uses evidence from the execution results
               - Shows logical reasoning
               - Acknowledges limitations
            
            5. **Quality Assurance**:
               - Verify answer completeness
               - Check for logical consistency
               - Ensure proper citations
            
            **FINAL ANSWER FORMAT:**
            - **Direct Answer**: Clear, concise response to the question
            - **Supporting Evidence**: Key findings from the execution
            - **Reasoning**: How you arrived at this conclusion  
            - **Sources**: Citations from the tool results
            - **Confidence**: Your confidence level and any limitations
            """,
            expected_output=(
                "A comprehensive final answer with: "
                "1) Direct response to the question, "
                "2) Supporting evidence and reasoning, "
                "3) Proper citations, "
                "4) Confidence assessment and limitations"
            )
        )

class ReWOOOrchestrator:
    """Main orchestrator for the ReWOO pattern"""
    
    def __init__(self, model: str = "gpt-4o-mini"):
        self.model = model
        self.planner = ReWOOPlanner.create_planner_agent(model)
        self.worker = ReWOOWorker.create_worker_agent(model)
        self.solver = ReWOOSolver.create_solver_agent(model)
    
    def run_rewoo_query(self, question: str) -> Dict[str, Any]:
        """Execute complete ReWOO process"""
        
        print(f"🎯 ReWOO Processing: {question}")
        print("=" * 60)
        
        results = {
            "question": question,
            "plan": None,
            "execution_results": None,
            "final_answer": None
        }
        
        try:
            # Phase 1: Planning
            print("📋 Phase 1: Planning")
            print("-" * 20)
            
            planning_task = ReWOOPlanner.create_planning_task(question)
            planning_crew = Crew(
                agents=[self.planner],
                tasks=[planning_task],
                process=Process.sequential,
                verbose=True
            )
            
            plan = planning_crew.kickoff()
            results["plan"] = str(plan)
            print(f"✅ Plan Created:\n{plan}\n")
            
            # Phase 2: Execution
            print("⚙️ Phase 2: Execution")
            print("-" * 20)
            
            execution_task = ReWOOWorker.create_execution_task(str(plan), question)
            execution_crew = Crew(
                agents=[self.worker],
                tasks=[execution_task],
                process=Process.sequential,
                verbose=True
            )
            
            execution_results = execution_crew.kickoff()
            results["execution_results"] = str(execution_results)
            print(f"✅ Execution Complete:\n{execution_results}\n")
            
            # Phase 3: Solving
            print("🧠 Phase 3: Solving")
            print("-" * 20)
            
            solving_task = ReWOOSolver.create_solving_task(str(execution_results), question)
            solving_crew = Crew(
                agents=[self.solver],
                tasks=[solving_task],
                process=Process.sequential,
                verbose=True
            )
            
            final_answer = solving_crew.kickoff()
            results["final_answer"] = str(final_answer)
            print(f"✅ Final Answer:\n{final_answer}\n")
            
            return results
            
        except Exception as e:
            print(f"❌ Error in ReWOO process: {str(e)}")
            results["error"] = str(e)
            return results

# Example usage and test cases
def demonstrate_rewoo_examples():
    """Demonstrate ReWOO with various example questions"""
    
    orchestrator = ReWOOOrchestrator()
    
    examples = [
        {
            "category": "Multi-step Mathematical Analysis",
            "question": "Calculate the compound annual growth rate for a company that grew from $2M revenue in 2020 to $3.5M in 2023, then predict the 2024 revenue using this rate."
        },
        {
            "category": "Research and Comparison",
            "question": "Compare the market share of the top 3 cloud computing providers and calculate which one has the highest growth rate."
        },
        {
            "category": "Financial Analysis",
            "question": "Find the current stock prices of Apple, Google, and Microsoft, then calculate which has the best P/E ratio and why."
        },
        {
            "category": "Trend Analysis",
            "question": "Research the latest trends in artificial intelligence for 2024, identify the top 3 trends, and explain their potential market impact."
        }
    ]
    
    print("🎨 ReWOO Pattern Demonstrations")
    print("=" * 50)
    
    for i, example in enumerate(examples, 1):
        print(f"\n🔍 Example {i}: {example['category']}")
        print(f"Question: {example['question']}")
        print("-" * 40)
        
        try:
            result = orchestrator.run_rewoo_query(example['question'])
            print("📊 Summary:")
            print(f"✅ Planning: {'Success' if result.get('plan') else 'Failed'}")
            print(f"✅ Execution: {'Success' if result.get('execution_results') else 'Failed'}")
            print(f"✅ Final Answer: {'Success' if result.get('final_answer') else 'Failed'}")
            
            if result.get('final_answer'):
                # Show truncated final answer
                answer = str(result['final_answer'])[:200] + "..." if len(str(result['final_answer'])) > 200 else str(result['final_answer'])
                print(f"📝 Answer Preview: {answer}")
            
        except Exception as e:
            print(f"❌ Example failed: {str(e)}")
        
        print("\n" + "="*50)

def interactive_rewoo_session():
    """Run an interactive ReWOO session"""
    
    print("🤖 Welcome to Interactive ReWOO Agent!")
    print("Ask complex questions that require multi-step reasoning.")
    print("Type 'quit' to exit, 'help' for examples.\n")
    
    orchestrator = ReWOOOrchestrator()
    
    while True:
        question = input("❓ Your question: ").strip()
        
        if question.lower() in ['quit', 'exit', 'q']:
            print("👋 Goodbye!")
            break
        
        if question.lower() == 'help':
            print_help_examples()
            continue
        
        if not question:
            continue
        
        try:
            result = orchestrator.run_rewoo_query(question)
            
            if result.get('final_answer'):
                print(f"\n✅ Final Answer:")
                print(f"{result['final_answer']}\n")
            else:
                print("❌ Failed to generate complete answer")
                if result.get('error'):
                    print(f"Error: {result['error']}")
            
            print("-" * 60)
            
        except Exception as e:
            print(f"❌ Error: {e}\n")

def print_help_examples():
    """Print example questions for the interactive session"""
    
    examples = [
        "Calculate ROI for an investment and compare it to market average",
        "Research latest AI trends and predict which will be most profitable",
        "Find population growth rates of major cities and rank them",
        "Compare renewable energy adoption across countries",
        "Analyze cryptocurrency trends and predict future movements"
    ]
    
    print("\n💡 Example Questions:")
    for i, example in enumerate(examples, 1):
        print(f"{i}. {example}")
    print()

def compare_react_vs_rewoo():
    """Compare ReAct vs ReWOO approaches"""
    
    comparison = """
    🔄 ReAct vs ReWOO Comparison:
    
    **ReAct (Reasoning + Acting):**
    ✅ Iterative thinking and acting
    ✅ Can adapt plan based on observations  
    ✅ More flexible for unpredictable tasks
    ❌ Can be inefficient with redundant tool calls
    ❌ May get stuck in loops
    
    **ReWOO (Reasoning WithOut Observation):**
    ✅ Efficient execution with clear planning
    ✅ No redundant tool calls
    ✅ Better for complex multi-step problems
    ✅ More predictable execution time
    ❌ Less adaptive to unexpected results
    ❌ Planning quality critical for success
    
    **When to use ReWOO:**
    - Complex questions requiring multiple steps
    - When you want predictable execution
    - For cost-sensitive applications
    - When planning quality is high
    
    **When to use ReAct:**  
    - Exploratory research tasks
    - When adaptability is crucial
    - For simpler, more dynamic problems
    - When intermediate feedback is valuable
    """
    
    print(comparison)

# Main execution
if __name__ == "__main__":
    
    # Quick test
    print("🧪 Quick ReWOO Test")
    print("-" * 20)
    
    orchestrator = ReWOOOrchestrator()
    test_question = "What's 15% of 1000, and how does that compare to 20% of 800?"
    
    try:
        result = orchestrator.run_rewoo_query(test_question)
        print(f"Test completed successfully!")
    except Exception as e:
        print(f"Test failed: {e}")
    
    # Show comparison
    compare_react_vs_rewoo()
    
    # Uncomment to run demonstrations
    # demonstrate_rewoo_examples()
    interactive_rewoo_session()