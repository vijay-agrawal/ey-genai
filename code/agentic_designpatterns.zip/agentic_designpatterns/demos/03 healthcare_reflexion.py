#!/usr/bin/env python3
import os
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from textwrap import dedent

"""
REFLEXION PATTERN:
- A dedicated agent reviews and challenges initial decisions
- Implements self-correction and quality assurance
- Forces the system to reconsider and improve initial outputs
- Mimics peer review process in professional settings
"""

load_dotenv()
MODEL = os.getenv("MODEL_NAME","gpt-4o-mini")

def read_notes():
    with open("data/clinical_notes.txt","r") as f:
        return f.read()

author = Agent(
    role="Clinical Author",
    goal="Draft a safe and clear discharge summary from raw notes.",
    backstory="Hospitalist who communicates clearly with patients and caregivers.",
    model=MODEL
)

critic = Agent(
    role="Clinical QA Critic",
    goal="Detect safety issues, omissions, and unclear language; suggest fixes.",
    backstory="Quality officer with a strict rubric: meds, follow-up, red flags, and plain language.",
    model=MODEL
)

draft_task = Task(
    description=dedent("""\
    Using the clinical notes provided, create a discharge summary with these sections:
    - Diagnosis & Hospital Course
    - Medications (dose, schedule, changes)
    - Follow-up & Monitoring
    - Patient Instructions (plain language)
    Keep to ~180-220 words.
    """),
    agent=author
)

review_task = Task(
    description=dedent("""\
    Review the draft against this rubric:
    1) Meds: doses/schedule clear? contraindications?
    2) Follow-up: timelines and provider?
    3) Red flags: when to seek help?
    4) Clarity: avoid jargon.
    Return a short critique and a revised summary.
    """),
    agent=critic
)

crew = Crew(agents=[author, critic], tasks=[draft_task, review_task], process=Process.sequential)

if __name__ == "__main__":
    notes = read_notes()
    draft_task.context = [notes]
    result = crew.kickoff()
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/healthcare_reflexion_summary.md","w") as f: f.write(str(result))
    print("=== Healthcare Critic–Author (Reflexion) Result ===")
    print(result)
