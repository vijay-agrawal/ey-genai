import os
import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from crewai_tools import tool
from textwrap import dedent
import warnings
warnings.filterwarnings('ignore')


"""
SUPERVISOR-WORKER PATTERN EXPLANATION:
This pattern follows a hierarchical structure where:
1. One supervisor agent coordinates and delegates work to multiple worker agents
2. Worker agents perform specialized tasks independently
3. The supervisor reviews all outputs and makes final decisions
4. Communication flows top-down (delegation) and bottom-up (reporting)
"""

"""
Enhanced Credit Risk Assessment System with Supervisor-Worker Pattern

This implementation includes:
- Proper tool definitions with validation
- Realistic risk scoring models
- Regulatory compliance checks
- Audit trails and logging
- Error handling and data validation
- Industry-standard metrics and thresholds
"""

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('outputs/audit_log.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

load_dotenv()
MODEL = os.getenv("MODEL_NAME", "gpt-4o-mini")

@dataclass
class RiskThresholds:
    """Industry-standard risk assessment thresholds"""
    FICO_EXCELLENT = 800
    FICO_GOOD = 670
    FICO_FAIR = 580
    FICO_POOR = 500
    
    DTI_LOW = 0.36
    DTI_MODERATE = 0.43
    DTI_HIGH = 0.50
    
    DELINQUENCY_ACCEPTABLE = 0
    DELINQUENCY_CONCERNING = 2
    
    INCOME_MINIMUM = 25000
    AGE_MINIMUM = 18

# --- Enhanced Tools with Validation ---

@tool("Load Credit Applications")
def load_credit_applications() -> str:
    """
    Load credit applications from CSV with comprehensive validation.
    Returns: JSON string of validated applications or error message.
    """
    try:
        if not os.path.exists("data/credit_applications.csv"):
            # Create sample data if file doesn't exist
            create_sample_data()
        
        df = pd.read_csv("data/credit_applications.csv")
        logger.info(f"Loaded {len(df)} credit applications")
        
        # Data validation
        required_cols = ['app_id', 'fico', 'income', 'debt', 'delinq_12m', 'age', 'employment_length']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns: {missing_cols}")
        
        # Clean and validate data
        df = validate_application_data(df)
        
        return df.to_json(orient='records', indent=2)
    except Exception as e:
        error_msg = f"Error loading applications: {str(e)}"
        logger.error(error_msg)
        return error_msg

@tool("Calculate Risk Metrics")
def calculate_risk_metrics(applications_json: str) -> str:
    """
    Calculate comprehensive risk metrics including DTI, risk scores, and flags.
    Args: applications_json - JSON string of credit applications
    Returns: JSON string with calculated metrics
    """
    try:
        df = pd.read_json(applications_json)
        logger.info(f"Calculating risk metrics for {len(df)} applications")
        
        # Calculate DTI ratio
        df['dti_ratio'] = (df['debt'] / df['income']).round(4)
        
        # Calculate FICO-based risk score (0-100, higher = riskier)
        df['fico_risk_score'] = calculate_fico_risk_score(df['fico'])
        
        # Calculate composite risk score
        df['composite_risk_score'] = calculate_composite_risk_score(df)
        
        # Generate risk flags
        df['risk_flags'] = df.apply(generate_risk_flags, axis=1)
        
        # Risk tier classification
        df['risk_tier'] = df['composite_risk_score'].apply(classify_risk_tier)
        
        # Regulatory compliance flags
        df['compliance_flags'] = df.apply(check_regulatory_compliance, axis=1)
        
        # Expected loss estimate (simplified model)
        df['expected_loss_rate'] = calculate_expected_loss(df)
        
        logger.info("Risk metrics calculation completed")
        return df.to_json(orient='records', indent=2)
        
    except Exception as e:
        error_msg = f"Error calculating risk metrics: {str(e)}"
        logger.error(error_msg)
        return error_msg

@tool("Generate Portfolio Analytics")
def generate_portfolio_analytics(applications_with_metrics_json: str) -> str:
    """
    Generate portfolio-level analytics and risk distribution.
    Args: applications_with_metrics_json - JSON with risk metrics
    Returns: Portfolio analytics summary
    """
    try:
        df = pd.read_json(applications_with_metrics_json)
        
        analytics = {
            "portfolio_summary": {
                "total_applications": len(df),
                "total_requested_amount": df['debt'].sum() if 'requested_amount' not in df.columns else df['requested_amount'].sum(),
                "average_fico": df['fico'].mean().round(0),
                "median_fico": df['fico'].median(),
                "average_dti": df['dti_ratio'].mean().round(3),
                "average_income": df['income'].mean().round(0)
            },
            "risk_distribution": {
                "low_risk": len(df[df['risk_tier'] == 'Low']),
                "medium_risk": len(df[df['risk_tier'] == 'Medium']),
                "high_risk": len(df[df['risk_tier'] == 'High']),
                "very_high_risk": len(df[df['risk_tier'] == 'Very High'])
            },
            "risk_percentages": {
                "low_risk_pct": (len(df[df['risk_tier'] == 'Low']) / len(df) * 100).round(1),
                "medium_risk_pct": (len(df[df['risk_tier'] == 'Medium']) / len(df) * 100).round(1),
                "high_risk_pct": (len(df[df['risk_tier'] == 'High']) / len(df) * 100).round(1),
                "very_high_risk_pct": (len(df[df['risk_tier'] == 'Very High']) / len(df) * 100).round(1)
            },
            "compliance_issues": {
                "total_with_compliance_flags": len(df[df['compliance_flags'].str.len() > 2]),
                "common_issues": identify_common_compliance_issues(df)
            },
            "expected_portfolio_loss_rate": df['expected_loss_rate'].mean().round(4)
        }
        
        return pd.Series(analytics).to_json(indent=2)
        
    except Exception as e:
        error_msg = f"Error generating portfolio analytics: {str(e)}"
        logger.error(error_msg)
        return error_msg

@tool("Check Regulatory Compliance")
def check_regulatory_compliance_tool(applications_json: str) -> str:
    """
    Perform regulatory compliance checks (ECOA, Fair Credit Reporting Act, etc.)
    Args: applications_json - JSON of applications
    Returns: Compliance report
    """
    try:
        df = pd.read_json(applications_json)
        
        compliance_report = {
            "ecoa_compliance": check_ecoa_compliance(df),
            "fcra_compliance": check_fcra_compliance(df),
            "ability_to_repay": check_ability_to_repay(df),
            "adverse_action_required": identify_adverse_actions(df)
        }
        
        return pd.Series(compliance_report).to_json(indent=2)
        
    except Exception as e:
        error_msg = f"Error in compliance check: {str(e)}"
        logger.error(error_msg)
        return error_msg

# --- Utility Functions ---

def create_sample_data():
    """Create realistic sample credit application data"""
    np.random.seed(42)
    n_apps = 25
    
    # Generate realistic synthetic data
    data = {
        'app_id': [f'APP_{str(i+1001).zfill(6)}' for i in range(n_apps)],
        'fico': np.random.normal(680, 80, n_apps).astype(int).clip(400, 850),
        'income': np.random.lognormal(np.log(65000), 0.5, n_apps).astype(int),
        'debt': np.random.lognormal(np.log(8000), 0.8, n_apps).astype(int),
        'delinq_12m': np.random.poisson(0.5, n_apps),
        'age': np.random.normal(35, 12, n_apps).astype(int).clip(18, 80),
        'employment_length': np.random.gamma(2, 3, n_apps).astype(int).clip(0, 40),
        'requested_amount': np.random.lognormal(np.log(15000), 0.6, n_apps).astype(int)
    }
    
    df = pd.DataFrame(data)
    os.makedirs("data", exist_ok=True)
    df.to_csv("data/credit_applications.csv", index=False)
    logger.info(f"Created sample data with {n_apps} applications")

def validate_application_data(df: pd.DataFrame) -> pd.DataFrame:
    """Validate and clean application data"""
    # Remove duplicates
    df = df.drop_duplicates(subset=['app_id'])
    
    # Handle missing values
    df = df.dropna(subset=['app_id', 'fico', 'income'])
    
    # Validate ranges
    df = df[df['fico'].between(300, 850)]
    df = df[df['income'] > 0]
    df = df[df['debt'] >= 0]
    df = df[df['age'] >= 18]
    
    # Cap extreme values
    df['delinq_12m'] = df['delinq_12m'].clip(0, 10)
    
    return df

def calculate_fico_risk_score(fico_scores: pd.Series) -> pd.Series:
    """Convert FICO scores to risk scores (0-100, higher = riskier)"""
    # Inverse relationship: higher FICO = lower risk
    return ((850 - fico_scores) / 450 * 100).round(1)

def calculate_composite_risk_score(df: pd.DataFrame) -> pd.Series:
    """Calculate composite risk score using multiple factors"""
    # Weighted scoring model
    weights = {
        'fico_weight': 0.40,
        'dti_weight': 0.25,
        'delinq_weight': 0.20,
        'income_weight': 0.10,
        'employment_weight': 0.05
    }
    
    # Normalize components to 0-100 scale
    fico_component = df['fico_risk_score']
    dti_component = (df['dti_ratio'].clip(0, 1) * 100)
    delinq_component = (df['delinq_12m'].clip(0, 5) / 5 * 100)
    income_component = ((100000 - df['income'].clip(0, 100000)) / 100000 * 100)
    employment_component = ((10 - df['employment_length'].clip(0, 10)) / 10 * 100)
    
    composite_score = (
        fico_component * weights['fico_weight'] +
        dti_component * weights['dti_weight'] +
        delinq_component * weights['delinq_weight'] +
        income_component * weights['income_weight'] +
        employment_component * weights['employment_weight']
    )
    
    return composite_score.round(1)

def generate_risk_flags(row: pd.Series) -> str:
    """Generate risk flags for each application"""
    flags = []
    
    if row['fico'] < RiskThresholds.FICO_FAIR:
        flags.append("LOW_FICO")
    if row['dti_ratio'] > RiskThresholds.DTI_HIGH:
        flags.append("HIGH_DTI")
    if row['delinq_12m'] > RiskThresholds.DELINQUENCY_CONCERNING:
        flags.append("DELINQUENCY_HISTORY")
    if row['income'] < RiskThresholds.INCOME_MINIMUM:
        flags.append("LOW_INCOME")
    if row['employment_length'] < 2:
        flags.append("SHORT_EMPLOYMENT")
    
    return "|".join(flags) if flags else "NONE"

def classify_risk_tier(composite_score: float) -> str:
    """Classify applications into risk tiers"""
    if composite_score <= 25:
        return "Low"
    elif composite_score <= 50:
        return "Medium"
    elif composite_score <= 75:
        return "High"
    else:
        return "Very High"

def check_regulatory_compliance(row: pd.Series) -> str:
    """Check for regulatory compliance issues"""
    issues = []
    
    if row['age'] < 18:
        issues.append("UNDERAGE")
    if pd.isna(row['income']) or row['income'] <= 0:
        issues.append("NO_INCOME_VERIFICATION")
    
    return "|".join(issues) if issues else "COMPLIANT"

def calculate_expected_loss(df: pd.DataFrame) -> pd.Series:
    """Calculate expected loss rates based on risk factors"""
    # Simplified model - in reality this would use historical data
    base_loss_rate = 0.02  # 2% base loss rate
    
    # Adjust based on risk factors
    fico_multiplier = np.where(df['fico'] < 580, 3.0,
                      np.where(df['fico'] < 620, 2.0,
                      np.where(df['fico'] < 670, 1.5, 1.0)))
    
    dti_multiplier = np.where(df['dti_ratio'] > 0.5, 2.5,
                     np.where(df['dti_ratio'] > 0.43, 1.8, 1.0))
    
    delinq_multiplier = 1 + (df['delinq_12m'] * 0.5)
    
    expected_loss = base_loss_rate * fico_multiplier * dti_multiplier * delinq_multiplier
    
    return expected_loss.round(4)

def identify_common_compliance_issues(df: pd.DataFrame) -> dict:
    """Identify the most common compliance issues in the portfolio"""
    all_flags = df['compliance_flags'].str.split('|').explode()
    return all_flags.value_counts().to_dict()

def check_ecoa_compliance(df: pd.DataFrame) -> dict:
    """Check Equal Credit Opportunity Act compliance"""
    return {
        "protected_class_data_collected": False,  # Should not collect race, religion, etc.
        "age_discrimination_risk": len(df[df['age'] < 25]) / len(df),
        "compliant": True
    }

def check_fcra_compliance(df: pd.DataFrame) -> dict:
    """Check Fair Credit Reporting Act compliance"""
    return {
        "adverse_action_notices_required": len(df[df['composite_risk_score'] > 60]),
        "credit_score_disclosure_required": True,
        "compliant": True
    }

def check_ability_to_repay(df: pd.DataFrame) -> dict:
    """Check ability-to-repay requirements"""
    qualified_mortgages = len(df[df['dti_ratio'] <= 0.43])
    return {
        "qm_eligible_count": qualified_mortgages,
        "high_dti_count": len(df[df['dti_ratio'] > 0.43]),
        "compliant": True
    }

def identify_adverse_actions(df: pd.DataFrame) -> list:
    """Identify applications requiring adverse action notices"""
    adverse_actions = []
    for _, row in df.iterrows():
        if row['composite_risk_score'] > 70:
            adverse_actions.append({
                "app_id": row['app_id'],
                "reason": "High composite risk score",
                "primary_factors": row['risk_flags'].split('|')
            })
    return adverse_actions

# --- Enhanced Agents with Tools ---

supervisor = Agent(
    role="Senior Credit Risk Manager",
    goal="Oversee comprehensive credit risk assessment, ensure regulatory compliance, and provide strategic recommendations for portfolio management.",
    backstory=dedent("""\
        You are a seasoned credit risk professional with 15+ years of experience in consumer lending.
        You understand regulatory requirements (ECOA, FCRA, Dodd-Frank) and industry best practices.
        You prioritize both risk mitigation and business growth, ensuring decisions are auditable and defensible.
        """),
    tools=[load_credit_applications, check_regulatory_compliance_tool],
    allow_delegation=True,
    model=MODEL,
    verbose=True
)

risk_analyst = Agent(
    role="Quantitative Risk Analyst",
    goal="Perform detailed risk calculations, statistical analysis, and generate predictive risk scores using industry-standard models.",
    backstory=dedent("""\
        You are a quantitative analyst specializing in credit risk modeling.
        You have expertise in statistical modeling, machine learning, and regulatory risk metrics.
        You ensure all calculations are accurate, well-documented, and comply with model governance standards.
        """),
    tools=[calculate_risk_metrics, generate_portfolio_analytics],
    allow_delegation=False,
    model=MODEL,
    verbose=True
)

compliance_officer = Agent(
    role="Credit Compliance Officer", 
    goal="Ensure all credit decisions comply with federal and state regulations, identify potential fair lending issues, and recommend risk mitigation strategies.",
    backstory=dedent("""\
        You are a compliance professional with deep knowledge of consumer credit regulations.
        You focus on ECOA, FCRA, state lending laws, and fair lending practices.
        You provide clear guidance on regulatory requirements and help structure compliant processes.
        """),
    tools=[check_regulatory_compliance_tool],
    allow_delegation=False,
    model=MODEL,
    verbose=True
)

# --- Enhanced Tasks ---

data_loading_task = Task(
    description=dedent("""\
        Load and validate the credit application portfolio:
        1. Load all pending credit applications from the data source
        2. Perform comprehensive data validation and cleaning
        3. Document any data quality issues found
        4. Provide summary statistics of the loaded portfolio
        
        Ensure all required fields are present and within acceptable ranges.
        """),
    agent=supervisor,
    expected_output="Clean, validated dataset with summary statistics and any data quality notes.",
    tools=[load_credit_applications]
)

risk_analysis_task = Task(
    description=dedent("""\
        Perform comprehensive risk analysis on all applications:
        1. Calculate key risk metrics (DTI, risk scores, expected loss rates)
        2. Generate individual risk classifications and flags
        3. Create portfolio-level analytics and risk distribution
        4. Identify high-risk applications requiring immediate attention
        
        Use industry-standard risk models and ensure all calculations are auditable.
        Document methodology and assumptions used in risk scoring.
        """),
    agent=risk_analyst,
    expected_output="Detailed risk assessment with individual scores, portfolio analytics, and methodology documentation.",
    tools=[calculate_risk_metrics, generate_portfolio_analytics]
)

compliance_review_task = Task(
    description=dedent("""\
        Conduct thorough regulatory compliance review:
        1. Check ECOA (Equal Credit Opportunity Act) compliance
        2. Verify FCRA (Fair Credit Reporting Act) requirements
        3. Assess ability-to-repay compliance for applicable products
        4. Identify applications requiring adverse action notices
        5. Flag any potential fair lending concerns
        
        Provide specific recommendations for addressing any compliance issues.
        """),
    agent=compliance_officer,
    expected_output="Comprehensive compliance report with specific findings and remediation recommendations.",
    tools=[check_regulatory_compliance_tool]
)

final_recommendations_task = Task(
    description=dedent("""\
        Synthesize all analysis into actionable recommendations:
        1. Review risk analysis and compliance findings
        2. Provide specific approve/review/decline recommendations for each application
        3. Include business rationale and regulatory justification for each decision
        4. Suggest portfolio-level risk management strategies
        5. Highlight any applications requiring manual underwriter review
        
        Ensure all recommendations are:
        - Risk-appropriate and defendable
        - Compliant with all applicable regulations  
        - Aligned with business objectives
        - Properly documented for audit purposes
        """),
    agent=supervisor,
    expected_output="Executive summary with specific recommendations, business rationale, and implementation guidance.",
    context=[data_loading_task, risk_analysis_task, compliance_review_task]
)

# --- Enhanced Crew Configuration ---

credit_risk_crew = Crew(
    agents=[supervisor, risk_analyst, compliance_officer],
    tasks=[data_loading_task, risk_analysis_task, compliance_review_task, final_recommendations_task],
    process=Process.sequential,
    verbose=True,
    memory=True,
    embedder={
        "provider": "openai",
        "config": {"model": "text-embedding-3-small"}
    }
)

def main():
    """Main execution function with enhanced error handling and reporting"""
    try:
        logger.info("Starting Enhanced Credit Risk Assessment System")
        
        # Ensure output directory exists
        os.makedirs("outputs", exist_ok=True)
        
        # Execute the crew
        result = credit_risk_crew.kickoff()
        
        # Save results with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"outputs/credit_risk_assessment_{timestamp}.md"
        
        with open(output_file, "w") as f:
            f.write(f"# Credit Risk Assessment Report\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**Model Used:** {MODEL}\n\n")
            f.write("---\n\n")
            f.write(str(result))
        
        # Also save as latest
        with open("outputs/latest_credit_risk_report.md", "w") as f:
            f.write(str(result))
        
        logger.info(f"Assessment completed successfully. Report saved to {output_file}")
        
        print("\n" + "="*80)
        print("ENHANCED CREDIT RISK ASSESSMENT - EXECUTIVE SUMMARY")
        print("="*80)
        print(result)
        print("="*80)
        
    except Exception as e:
        logger.error(f"Error during assessment execution: {str(e)}")
        raise

if __name__ == "__main__":
    main()