# Import required libraries
from crewai import Agent, Task, Crew, Process
from langchain.tools import Tool
from langchain.memory import ConversationBufferMemory

"""
COLLABORATION + REFLEXION PATTERN EXPLANATION:

COLLABORATION PATTERN:
- Multiple specialist agents work together as peers (no hierarchy)
- Each agent contributes their expertise to a shared goal
- Agents can build upon each other's work through task contexts
- Information flows horizontally between agents

REFLEXION PATTERN:
- A dedicated agent reviews and challenges initial decisions
- Implements self-correction and quality assurance
- Forces the system to reconsider and improve initial outputs
- Mimics peer review process in professional settings
"""

# ===============================
# MEMORY SETUP
# ===============================

# Memory enables agents to maintain context across interactions
# This is crucial for healthcare where patient history matters
memory = ConversationBufferMemory()

# ===============================
# COLLABORATIVE AGENTS (Peer-level specialists)
# ===============================

# SPECIALIST AGENT 1 - Medical imaging expert
radiologist = Agent(
    role='Radiologist',
    goal='Analyze medical images and provide insights',
    backstory='Specialist in medical imaging interpretation',
    memory=True,  # Enables memory to track patient context
)

# SPECIALIST AGENT 2 - Laboratory analysis expert
pathologist = Agent(
    role='Pathologist',
    goal='Analyze lab results and tissue samples',
    backstory='Expert in laboratory diagnostics',
    memory=True,  # Shares memory context with other agents
)

# SPECIALIST AGENT 3 - Clinical decision maker
clinician = Agent(
    role='Clinical Doctor',
    goal='Integrate findings for diagnosis',
    backstory='Experienced physician with broad medical knowledge',
    memory=True,  # Accesses combined insights from specialists
)

# ===============================
# REFLEXION AGENT (Quality assurance)
# ===============================

# REFLEXION AGENT - Reviews and challenges decisions
reviewer = Agent(
    role='Medical Reviewer',
    goal='Review and challenge initial diagnosis',
    backstory='Senior physician focused on diagnostic accuracy',
    memory=True,  # Remembers all previous analyses
    verbose=True  # Shows detailed reasoning process
)

# ===============================
# COLLABORATIVE TASKS
# ===============================

# PARALLEL ANALYSIS TASKS - Can run simultaneously
# Each specialist works independently on their domain

# TASK 1 - Image analysis (independent)
image_analysis = Task(
    description='Analyze chest X-ray for abnormalities',
    agent=radiologist,
    expected_output='Radiological findings report'
)

# TASK 2 - Laboratory analysis (independent)
lab_analysis = Task(
    description='Interpret blood work and lab values',
    agent=pathologist,
    expected_output='Laboratory analysis report'
)

# TASK 3 - Initial integration (depends on above tasks)
initial_diagnosis = Task(
    description='Combine imaging and lab results for preliminary diagnosis',
    agent=clinician,
    expected_output='Initial diagnostic assessment'
    # This task will automatically receive outputs from image_analysis and lab_analysis
)

# ===============================
# REFLEXION TASKS (Self-correction mechanism)
# ===============================

# REFLEXION TASK 1 - Critical review
diagnosis_review = Task(
    description='Review initial diagnosis, identify gaps, suggest additional tests',
    agent=reviewer,
    expected_output='Diagnostic review with recommendations',
    # CRITICAL: context parameter makes this task aware of previous analyses
    context=[image_analysis, lab_analysis, initial_diagnosis]
)

# REFLEXION TASK 2 - Improved final output
final_diagnosis = Task(
    description='Incorporate review feedback for final diagnosis',
    agent=clinician,  # Original clinician refines their diagnosis
    expected_output='Final diagnosis and treatment plan',
    context=[diagnosis_review]  # Uses feedback from reviewer
)

# ===============================
# CREW CONFIGURATION
# ===============================

# Create collaborative crew with memory and reflexion
crew = Crew(
    # All agents participate as equals (no supervisor hierarchy)
    agents=[radiologist, pathologist, clinician, reviewer],
    
    # Task sequence: parallel → integration → reflexion → refinement
    tasks=[image_analysis, lab_analysis, initial_diagnosis, diagnosis_review, final_diagnosis],
    
    # Sequential process allows for task dependencies and context sharing
    process=Process.sequential,
    
    # MEMORY ENABLED - Agents remember interactions and context
    memory=True,
    verbose=True
)

# ===============================
# EXECUTION
# ===============================

result = crew.kickoff(inputs={'patient_data': 'Patient: 45yo male, chest pain, smoker'})

"""
EXECUTION FLOW WITH COLLABORATION + REFLEXION:

PHASE 1 - COLLABORATIVE ANALYSIS:
1. Radiologist and Pathologist work independently (can be parallel)
2. Clinician integrates both specialist findings
3. Initial diagnosis is formed through collaboration

PHASE 2 - REFLEXION PROCESS:
4. Reviewer critically examines all previous work
5. Identifies potential errors, gaps, or alternative interpretations
6. Suggests improvements or additional considerations

PHASE 3 - REFINEMENT:
7. Clinician incorporates reviewer feedback
8. Final diagnosis is improved through reflexion

BENEFITS:
- Collaboration: Multiple expertise domains combined
- Reflexion: Self-correction and quality improvement
- Memory: Consistent context across all interactions
- Reduced errors through peer review process
- More robust decision-making
"""