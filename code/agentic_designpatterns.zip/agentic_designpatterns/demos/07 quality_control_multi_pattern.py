# Import required libraries
from crewai import Agent, Task, Crew, Process
from langchain.memory import ConversationBufferMemory
from langchain.tools import Tool

"""
MULTI-PATTERN INTEGRATION EXPLANATION:

This demo combines multiple agentic AI patterns:

1. SUPERVISOR-WORKER: Hierarchical coordination with delegation
2. COLLABORATION: Peer-to-peer agent cooperation  
3. REFLEXION: Self-correction through review and challenge
4. MEMORY: Persistent context and learning across interactions

INTEGRATION BENEFITS:
- Leverages strengths of each pattern
- Creates robust, fault-tolerant systems
- Enables complex workflow orchestration
- Provides multiple quality assurance layers
- Supports continuous improvement through memory

REAL-WORLD APPLICATION:
Manufacturing quality control requires:
- Hierarchical oversight (supervisor)
- Specialist collaboration (inspection, analysis)
- Self-correction (quality review)
- Historical learning (memory of past issues)
"""

# ===============================
# MEMORY SETUP FOR STATE TRACKINGfrom crewai import Agent, Task, Crew, Process
from langchain.memory import ConversationBufferMemory
from langchain.tools import Tool

# Combining Supervisor-Worker, Collaboration, Memory & Reflexion

# Memory for state tracking
production_memory = ConversationBufferMemory()

# Supervisor Agent
quality_supervisor = Agent(
    role='Quality Control Supervisor',
    goal='Oversee production quality workflow',
    backstory='Senior QC manager coordinating quality teams',
    allow_delegation=True,
    memory=True
)

# Worker Agents (Collaborative)
inspector = Agent(
    role='Quality Inspector',
    goal='Inspect products for defects',
    backstory='Skilled inspector with defect detection expertise',
    tools=[
        Tool(name='visual_inspect', func=lambda x: f'Visual defects found: {x}'),
        Tool(name='measure', func=lambda x: f'Measurements: {x}')
    ],
    memory=True
)

analyst = Agent(
    role='Data Analyst',
    goal='Analyze quality trends and patterns',
    backstory='Statistical analyst tracking quality metrics',
    memory=True
)

# Reflexion Agent
reviewer = Agent(
    role='Quality Reviewer',
    goal='Review and challenge quality decisions',
    backstory='Senior engineer ensuring quality standards',
    memory=True
)

# Process Improvement Agent
optimizer = Agent(
    role='Process Optimizer',
    goal='Suggest manufacturing improvements',
    backstory='Continuous improvement specialist',
    memory=True
)

# Multi-pattern tasks
inspection_task = Task(
    description='Inspect batch of automotive parts for defects',
    agent=inspector,
    expected_output='Inspection report with defect analysis'
)

trend_analysis = Task(
    description='Analyze quality trends from inspection data',
    agent=analyst,
    expected_output='Quality trend analysis',
    context=[inspection_task]
)

quality_review = Task(
    description='Review inspection decisions and identify risks',
    agent=reviewer,
    expected_output='Quality review with risk assessment',
    context=[inspection_task, trend_analysis]
)

process_optimization = Task(
    description='Recommend process improvements based on findings',
    agent=optimizer,
    expected_output='Process improvement recommendations',
    context=[trend_analysis, quality_review]
)

final_decision = Task(
    description='Make final quality decision for production batch',
    agent=quality_supervisor,
    expected_output='Final quality decision and actions',
    context=[inspection_task, quality_review, process_optimization]
)

# Multi-pattern crew
crew = Crew(
    agents=[quality_supervisor, inspector, analyst, reviewer, optimizer],
    tasks=[inspection_task, trend_analysis, quality_review, process_optimization, final_decision],
    process=Process.hierarchical,
    manager_llm=OpenAI(temperature=0),
    memory=True,
    verbose=True
)

result = crew.kickoff(inputs={
    'batch_id': 'AUTO2025-001',
    'product_type': 'Engine components',
    'quality_target': '99.5% defect-free'
})