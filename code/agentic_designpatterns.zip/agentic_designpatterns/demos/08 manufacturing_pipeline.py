import os, pandas as pd
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from textwrap import dedent

load_dotenv()
MODEL = os.getenv("MODEL_NAME","gpt-4o-mini")

def load_defects():
    return pd.read_csv("data/manufacturing_defects.csv")

ingest = Agent(
    role="Ingestion Agent",
    goal="Read defect logs and produce a clean summary by lot and station.",
    backstory="Knows how to turn CSVs into compact summaries for engineers.",
    model=MODEL
)

analyze = Agent(
    role="Quality Analyst",
    goal="Identify top 2 systemic issues and suspected root causes.",
    backstory="Applies 5-Why style reasoning and links to stations.",
    model=MODEL
)

verify = Agent(
    role="QA Verifier",
    goal="Check that the proposed root causes align with the data and add confidence levels.",
    backstory="Skeptical and concise; demands evidence.",
    model=MODEL
)

publish = Agent(
    role="Incident Publisher",
    goal="Write a short incident bulletin for the plant Slack.",
    backstory="Communicates crisply with operators and supervisors.",
    model=MODEL
)

t1 = Task(
    description=dedent("""\
    Load manufacturing_defects.csv and provide a compact table:
    lot, station, defect, count and a per-lot total row.
    """),
    agent=ingest
)

t2 = Task(
    description=dedent("""\
    From the table, identify top 2 systemic issues and suspected root causes with evidence.
    """),
    agent=analyze
)

t3 = Task(
    description=dedent("""\
    Verify claims against the table; add confidence (High/Med/Low) and gaps to check.
    """),
    agent=verify
)

t4 = Task(
    description=dedent("""\
    Publish an incident bulletin (<=100 words) with:
    - Issues, stations, lots affected
    - Immediate containment & owner
    """),
    agent=publish
)

crew = Crew(agents=[ingest, analyze, verify, publish], tasks=[t1, t2, t3, t4], process=Process.sequential)

if __name__ == "__main__":
    df = load_defects()
    # Give t1 a head start context (table) so the model can "see" data deterministically
    t1.context = [df.to_markdown(index=False)]
    result = crew.kickoff()
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/manufacturing_pipeline_bulletin.md","w") as f: f.write(str(result))
    print("=== Manufacturing Pipeline / Assembly Line Result ===")
    print(result)
