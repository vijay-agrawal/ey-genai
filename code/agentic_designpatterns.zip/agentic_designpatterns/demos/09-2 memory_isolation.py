from crewai import Agent, Task, Crew, Process
from langchain.memory import ConversationBufferMemory, ConversationSummaryMemory
from langchain.llms import OpenAI

"""
PRACTICAL EXAMPLE: BANKING LOAN PROCESSING WITH SELECTIVE MEMORY

SCENARIO: A bank processes loan applications with different teams:
- Credit Assessment Team: Shares technical analysis memory
- Customer Service Team: Shares customer interaction memory  
- Risk Management Team: Shares risk evaluation memory
- Executive Team: Has private memory for sensitive decisions

MEMORY ISOLATION REASONS:
- Customer privacy: Service team shouldn't see risk assessments
- Confidentiality: Executives need private decision space
- Specialization: Teams focus on their domain expertise
- Compliance: Regulatory requirements for information access
"""

# ===============================
# MEMORY SETUP FOR DIFFERENT TEAMS
# ===============================

# 1. Credit Assessment Team Memory (shared between credit analysts)
credit_team_memory = ConversationBufferMemory()

# 2. Customer Service Team Memory (shared between service agents)
service_team_memory = ConversationBufferMemory()

# 3. Risk Management Team Memory (shared between risk specialists)
risk_team_memory = ConversationSummaryMemory(llm=OpenAI())

# 4. Executive Private Memory (confidential decision making)
executive_memory = ConversationBufferMemory()

# ===============================
# CREDIT ASSESSMENT TEAM (Shared Memory)
# ===============================

credit_analyst_1 = Agent(
    role='Senior Credit Analyst',
    goal='Analyze creditworthiness and financial stability',
    backstory='Expert in credit risk assessment with 10 years experience',
    memory=credit_team_memory,  # SHARED with other credit analysts
    verbose=True
)

credit_analyst_2 = Agent(
    role='Junior Credit Analyst', 
    goal='Support credit analysis with data gathering',
    backstory='Detail-oriented analyst specializing in financial data',
    memory=credit_team_memory,  # SAME MEMORY - can see senior analyst's work
    verbose=True
)

# ===============================
# CUSTOMER SERVICE TEAM (Shared Memory)
# ===============================

service_agent_1 = Agent(
    role='Customer Service Representative',
    goal='Handle customer inquiries and provide support',
    backstory='Experienced customer service agent with banking knowledge',
    memory=service_team_memory,  # SHARED with other service agents only
    verbose=True
)

service_agent_2 = Agent(
    role='Customer Relationship Manager',
    goal='Manage customer relationships and expectations',
    backstory='Relationship management specialist for banking clients',
    memory=service_team_memory,  # SAME MEMORY - knows customer interactions
    verbose=True
)

# ===============================
# RISK MANAGEMENT TEAM (Shared Memory)  
# ===============================

risk_analyst = Agent(
    role='Risk Assessment Specialist',
    goal='Evaluate loan risks and compliance requirements',
    backstory='Risk management expert with regulatory knowledge',
    memory=risk_team_memory,  # SHARED with other risk team members
    verbose=True
)

compliance_officer = Agent(
    role='Compliance Officer',
    goal='Ensure regulatory compliance and audit requirements',
    backstory='Compliance specialist with banking regulation expertise',
    memory=risk_team_memory,  # SAME MEMORY - sees risk assessments
    verbose=True
)

# ===============================
# EXECUTIVE TEAM (Private Memory)
# ===============================

loan_executive = Agent(
    role='Loan Committee Executive',
    goal='Make final loan approval decisions',
    backstory='Senior executive with loan committee authority',
    memory=executive_memory,  # PRIVATE MEMORY - confidential decisions
    allow_delegation=True,
    verbose=True
)

# ===============================
# TASK DEFINITIONS WITH MEMORY BOUNDARIES
# ===============================

# CREDIT TEAM TASKS (share credit_team_memory)
initial_credit_analysis = Task(
    description='Perform initial credit analysis on loan application',
    agent=credit_analyst_1,
    expected_output='Initial credit assessment report'
)

detailed_financial_review = Task(
    description='Conduct detailed financial analysis using senior analyst insights',
    agent=credit_analyst_2,
    expected_output='Detailed financial analysis report',
    context=[initial_credit_analysis]  # Can access through shared memory
)

# CUSTOMER SERVICE TASKS (share service_team_memory)
customer_communication = Task(
    description='Communicate with customer about application status',
    agent=service_agent_1,
    expected_output='Customer communication log'
)

relationship_management = Task(
    description='Manage customer expectations and provide updates',
    agent=service_agent_2,
    expected_output='Customer relationship status update',
    # Can access service_agent_1's communications through shared memory
)

# RISK TEAM TASKS (share risk_team_memory)
risk_evaluation = Task(
    description='Evaluate loan risk factors and regulatory compliance',
    agent=risk_analyst,
    expected_output='Risk assessment report'
)

compliance_review = Task(
    description='Review loan for regulatory compliance using risk analysis',
    agent=compliance_officer,
    expected_output='Compliance verification report',
    context=[risk_evaluation]  # Can access through shared memory
)

# EXECUTIVE TASK (private executive_memory)
final_decision = Task(
    description='Make final loan decision based on all team inputs',
    agent=loan_executive,
    expected_output='Final loan approval/rejection decision',
    # NOTE: Executive gets summarized inputs, not direct memory access
    context=[detailed_financial_review, relationship_management, compliance_review]
)

# ===============================
# INFORMATION FLOW CONTROL
# ===============================

class MemoryBoundaryManager:
    """
    Manages information flow between teams with different memory access levels
    """
    
    def __init__(self):
        self.team_boundaries = {
            'credit_team': ['credit_analyst_1', 'credit_analyst_2'],
            'service_team': ['service_agent_1', 'service_agent_2'], 
            'risk_team': ['risk_analyst', 'compliance_officer'],
            'executive_team': ['loan_executive']
        }
    
    def can_access_memory(self, requester_agent, target_memory_team):
        """Check if an agent can access another team's memory"""
        requester_team = self.get_agent_team(requester_agent)
        return requester_team == target_memory_team
    
    def get_agent_team(self, agent_id):
        """Determine which team an agent belongs to"""
        for team, agents in self.team_boundaries.items():
            if agent_id in agents:
                return team
        return None
    
    def get_shareable_summary(self, from_team, to_team, full_memory):
        """Create appropriate summary for cross-team communication"""
        if from_team == 'credit_team' and to_team == 'executive_team':
            return "Credit analysis complete - financial metrics within acceptable range"
        elif from_team == 'service_team' and to_team == 'executive_team':
            return "Customer communication handled - expectations managed appropriately"
        elif from_team == 'risk_team' and to_team == 'executive_team':
            return "Risk assessment complete - compliance requirements satisfied"
        else:
            return "Information not shareable between these teams"

# ===============================
# CREW CONFIGURATION WITH MEMORY BOUNDARIES
# ===============================

# Create crew with selective memory sharing
banking_crew = Crew(
    agents=[
        credit_analyst_1, credit_analyst_2,        # Credit team
        service_agent_1, service_agent_2,          # Service team  
        risk_analyst, compliance_officer,          # Risk team
        loan_executive                             # Executive (supervisor)
    ],
    tasks=[
        initial_credit_analysis, detailed_financial_review,  # Credit tasks
        customer_communication, relationship_management,      # Service tasks
        risk_evaluation, compliance_review,                  # Risk tasks
        final_decision                                       # Executive task
    ],
    process=Process.hierarchical,  # Executive can coordinate
    manager_llm=OpenAI(temperature=0),
    memory=False,  # Disable crew-level memory - using agent-level control
    verbose=True
)

# ===============================
# EXECUTION WITH MEMORY BOUNDARIES
# ===============================

def demonstrate_selective_memory():
    """Demonstrate how selective memory sharing works in practice"""
    
    print("=== BANKING LOAN PROCESSING WITH SELECTIVE MEMORY ===\n")
    
    print("MEMORY BOUNDARIES:")
    print("├── Credit Team Memory (shared)")
    print("│   ├── Senior Credit Analyst")  
    print("│   └── Junior Credit Analyst")
    print("├── Service Team Memory (shared)")
    print("│   ├── Customer Service Rep")
    print("│   └── Customer Relationship Manager")
    print("├── Risk Team Memory (shared)")
    print("│   ├── Risk Assessment Specialist")
    print("│   └── Compliance Officer") 
    print("└── Executive Memory (private)")
    print("    └── Loan Committee Executive")
    
    print("\nINFORMATION FLOW:")
    print("• Credit analysts share technical analysis")
    print("• Service agents share customer interactions")
    print("• Risk team shares compliance assessments") 
    print("• Executive receives summaries, not raw memories")
    print("• No cross-team memory access (privacy maintained)")
    
    return banking_crew.kickoff(inputs={
        'applicant_name': 'John Smith',
        'loan_amount': '$250,000',
        'loan_purpose': 'Home purchase',
        'applicant_income': '$95,000',
        'credit_score': '745'
    })

# Execute demonstration
result = demonstrate_selective_memory()

"""
KEY BENEFITS OF SELECTIVE MEMORY SHARING:

1. PRIVACY PROTECTION:
   - Customer service agents don't see risk assessments
   - Risk team doesn't access customer complaints
   - Executive decisions remain confidential

2. TEAM SPECIALIZATION:
   - Each team focuses on their expertise
   - Shared memory within teams improves collaboration
   - Reduces information overload

3. REGULATORY COMPLIANCE:
   - Controlled access to sensitive information
   - Audit trails for each team's decisions
   - Separation of duties maintained

4. SCALABILITY:
   - Easy to add new agents to existing teams
   - Clear memory boundaries prevent conflicts
   - Modular architecture supports growth

5. SECURITY:
   - Reduced risk of information leakage
   - Role-based memory access control
   - Sensitive data isolation

IMPLEMENTATION PATTERNS:
- Use different memory objects for different teams
- Share memory objects only within team boundaries  
- Use task context for controlled information passing
- Implement custom memory managers for complex scenarios
- Monitor memory usage and implement cleanup strategies
"""