from crewai import Agent, Task, Crew, Process
from langchain.memory import ConversationBufferMemory
from langchain.llms import OpenAI
from datetime import datetime, timedelta
from typing import Dict, List, Any
import json

"""
PRACTICAL EXAMPLE: E-COMMERCE CUSTOMER SERVICE WITH DUAL MEMORY

SCENARIO: Online retail customer service system that learns from:
1. EPISODIC MEMORY: Specific customer interactions and their outcomes
2. SEMANTIC MEMORY: General customer service knowledge and best practices

This creates a system that:
- Remembers individual customer histories (episodic)
- Learns general patterns about customer behavior (semantic)
- Provides personalized service based on past interactions
- Applies learned best practices across all customers
"""

# ===============================
# SIMPLIFIED MEMORY IMPLEMENTATIONS
# ===============================

class SimpleEpisodicMemory:
    """
    Simplified episodic memory for customer interactions
    Stores: customer_id, interaction_type, context, resolution, satisfaction
    """
    
    def __init__(self):
        self.interactions = []
    
    def remember_interaction(self, customer_id: str, interaction_type: str, 
                           context: Dict, resolution: str, satisfaction: int):
        """Store a specific customer interaction"""
        interaction = {
            'timestamp': datetime.now().isoformat(),
            'customer_id': customer_id,
            'interaction_type': interaction_type,  # 'complaint', 'inquiry', 'return', etc.
            'context': context,
            'resolution': resolution,
            'satisfaction_score': satisfaction,  # 1-5 scale
            'agent_id': context.get('agent_id', 'unknown')
        }
        self.interactions.append(interaction)
        return interaction
    
    def get_customer_history(self, customer_id: str, limit: int = 10) -> List[Dict]:
        """Get interaction history for specific customer"""
        customer_interactions = [
            interaction for interaction in self.interactions 
            if interaction['customer_id'] == customer_id
        ]
        return sorted(customer_interactions, 
                     key=lambda x: x['timestamp'], reverse=True)[:limit]
    
    def get_similar_cases(self, current_context: Dict, limit: int = 5) -> List[Dict]:
        """Find similar past interactions for pattern recognition"""
        similar = []
        for interaction in self.interactions:
            similarity_score = self.calculate_similarity(current_context, interaction['context'])
            if similarity_score > 0.3:  # Similarity threshold
                interaction['similarity'] = similarity_score
                similar.append(interaction)
        
        return sorted(similar, key=lambda x: x['similarity'], reverse=True)[:limit]
    
    def calculate_similarity(self, context1: Dict, context2: Dict) -> float:
        """Simple similarity calculation (in practice, use embeddings)"""
        common_keys = set(context1.keys()) & set(context2.keys())
        if not common_keys:
            return 0.0
        
        matches = sum(1 for key in common_keys 
                     if str(context1[key]).lower() == str(context2[key]).lower())
        return matches / len(common_keys)

class SimpleSemanticMemory:
    """
    Simplified semantic memory for customer service knowledge
    Stores: general rules, patterns, best practices, FAQs
    """
    
    def __init__(self):
        self.knowledge = {
            'patterns': {},      # Observed behavioral patterns
            'rules': {},        # Service rules and policies
            'solutions': {},    # Common problem-solution pairs
            'escalation_triggers': []  # Conditions that require escalation
        }
    
    def learn_pattern(self, pattern_name: str, description: str, evidence_count: int = 1):
        """Learn a new pattern from customer interactions"""
        if pattern_name in self.knowledge['patterns']:
            # Strengthen existing pattern
            self.knowledge['patterns'][pattern_name]['evidence_count'] += evidence_count
            self.knowledge['patterns'][pattern_name]['confidence'] = min(
                1.0, self.knowledge['patterns'][pattern_name]['evidence_count'] * 0.05
            )
        else:
            # Create new pattern
            self.knowledge['patterns'][pattern_name] = {
                'description': description,
                'evidence_count': evidence_count,
                'confidence': min(1.0, evidence_count * 0.05),
                'learned_date': datetime.now().isoformat()
            }
    
    def add_solution(self, problem_type: str, solution: str, success_rate: float):
        """Add a proven solution to the knowledge base"""
        if problem_type not in self.knowledge['solutions']:
            self.knowledge['solutions'][problem_type] = []
        
        self.knowledge['solutions'][problem_type].append({
            'solution': solution,
            'success_rate': success_rate,
            'added_date': datetime.now().isoformat()
        })
    
    def add_rule(self, category: str, rule: str, priority: str = 'normal'):
        """Add a service rule or policy"""
        if category not in self.knowledge['rules']:
            self.knowledge['rules'][category] = []
        
        self.knowledge['rules'][category].append({
            'rule': rule,
            'priority': priority,
            'created_date': datetime.now().isoformat()
        })
    
    def get_relevant_knowledge(self, context: Dict) -> Dict:
        """Retrieve knowledge relevant to current situation"""
        relevant = {
            'applicable_rules': [],
            'suggested_solutions': [],
            'relevant_patterns': [],
            'escalation_needed': False
        }
        
        # Find applicable rules
        for category, rules in self.knowledge['rules'].items():
            if any(keyword in str(context.values()).lower() 
                  for keyword in category.lower().split()):
                relevant['applicable_rules'].extend(rules)
        
        # Find suggested solutions
        problem_type = context.get('issue_type', 'general')
        if problem_type in self.knowledge['solutions']:
            relevant['suggested_solutions'] = self.knowledge['solutions'][problem_type]
        
        # Find relevant patterns
        for pattern_name, pattern_info in self.knowledge['patterns'].items():
            if pattern_info['confidence'] > 0.5:  # Only high-confidence patterns
                relevant['relevant_patterns'].append({
                    'name': pattern_name,
                    'description': pattern_info['description'],
                    'confidence': pattern_info['confidence']
                })
        
        return relevant

# ===============================
# INITIALIZE SHARED MEMORY SYSTEMS
# ===============================

# Shared episodic memory across all customer service agents
service_episodic_memory = SimpleEpisodicMemory()

# Shared semantic memory for accumulated knowledge
service_semantic_memory = SimpleSemanticMemory()

# Pre-populate with some initial knowledge
service_semantic_memory.add_rule(
    'refunds', 
    'Refunds for items over $100 require manager approval',
    'high'
)

service_semantic_memory.add_rule(
    'shipping',
    'Expedited shipping can be offered for delayed orders at no extra charge',
    'normal'
)

service_semantic_memory.add_solution(
    'login_issues',
    'Reset password and clear browser cache',
    0.85
)

service_semantic_memory.learn_pattern(
    'frustrated_repeat_customer',
    'Customers contacting support 3+ times for same issue show high frustration',
    evidence_count=25
)

# ===============================
# CUSTOMER SERVICE AGENTS WITH DUAL MEMORY
# ===============================

class CustomerServiceAgent(Agent):
    """Customer service agent with access to both memory types"""
    
    def __init__(self, episodic_memory: SimpleEpisodicMemory, 
                 semantic_memory: SimpleSemanticMemory, **kwargs):
        super().__init__(**kwargs)
        self.episodic_memory = episodic_memory
        self.semantic_memory = semantic_memory
        self.agent_id = kwargs.get('role', 'agent').replace(' ', '_').lower()
    
    def handle_customer(self, customer_id: str, issue_context: Dict) -> Dict:
        """Handle customer interaction using both memory types"""
        
        # EPISODIC: Get customer history
        customer_history = self.episodic_memory.get_customer_history(customer_id)
        similar_cases = self.episodic_memory.get_similar_cases(issue_context)
        
        # SEMANTIC: Get relevant knowledge
        relevant_knowledge = self.semantic_memory.get_relevant_knowledge(issue_context)
        
        # Make