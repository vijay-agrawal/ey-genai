from crewai import Agent, Task, Crew, Process
from langchain.memory import ConversationBufferMemory, ConversationSummaryMemory
from langchain.llms import OpenAI
from langchain.schema import BaseMemory
from datetime import datetime, timedelta
import json
from typing import Dict, List, Any

"""
EPISODIC vs SEMANTIC MEMORY EXPLANATION:

EPISODIC MEMORY:
- Stores specific experiences and events with temporal context
- "What happened when" - autobiographical memories
- Includes: timestamps, contexts, outcomes, emotional responses
- Example: "On March 15th, customer John complained about slow service"

SEMANTIC MEMORY:
- Stores general knowledge and facts without temporal context  
- "What I know" - conceptual knowledge and rules
- Includes: procedures, facts, patterns, best practices
- Example: "Customers who complain about service usually need immediate attention"

PRACTICAL APPLICATION:
- Episodic: Learn from specific past experiences
- Semantic: Apply general knowledge and rules
- Combined: Make informed decisions using both experience and knowledge
"""

# ===============================
# CUSTOM MEMORY IMPLEMENTATIONS
# ===============================

class EpisodicMemory(BaseMemory):
    """
    Custom episodic memory that stores specific experiences with context
    Each memory entry includes: event, timestamp, context, outcome, emotions
    """
    
    def __init__(self):
        self.experiences = []  # List of episodic memories
        self.memory_key = "episodic_history"
    
    def add_experience(self, event: str, context: Dict, outcome: str, emotion: str = None):
        """Add a new episodic memory with full context"""
        experience = {
            'timestamp': datetime.now().isoformat(),
            'event': event,
            'context': context,
            'outcome': outcome,
            'emotion': emotion,
            'memory_type': 'episodic'
        }
        self.experiences.append(experience)
    
    def get_recent_experiences(self, days: int = 7) -> List[Dict]:
        """Retrieve experiences from the last N days"""
        cutoff_date = datetime.now() - timedelta(days=days)
        recent = []
        for exp in self.experiences:
            exp_date = datetime.fromisoformat(exp['timestamp'])
            if exp_date >= cutoff_date:
                recent.append(exp)
        return recent
    
    def get_similar_experiences(self, current_context: Dict) -> List[Dict]:
        """Find past experiences similar to current situation"""
        similar = []
        for exp in self.experiences:
            # Simple similarity check - in practice, use embeddings
            if any(key in exp['context'] for key in current_context.keys()):
                similar.append(exp)
        return similar
    
    @property
    def memory_variables(self) -> List[str]:
        return [self.memory_key]
    
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        recent_experiences = self.get_recent_experiences()
        formatted_memories = []
        for exp in recent_experiences[-5:]:  # Last 5 experiences
            formatted_memories.append(
                f"[{exp['timestamp']}] {exp['event']} -> {exp['outcome']}"
            )
        return {self.memory_key: "\n".join(formatted_memories)}
    
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        # Context saving handled manually through add_experience method
        pass
    
    def clear(self) -> None:
        self.experiences = []

class SemanticMemory(BaseMemory):
    """
    Custom semantic memory that stores general knowledge and patterns
    Organizes knowledge by categories and confidence levels
    """
    
    def __init__(self):
        self.knowledge_base = {
            'rules': {},           # General rules and procedures
            'patterns': {},        # Observed patterns and correlations
            'facts': {},          # Factual knowledge
            'best_practices': {}  # Learned best practices
        }
        self.memory_key = "semantic_knowledge"
    
    def add_rule(self, category: str, rule: str, confidence: float = 1.0):
        """Add a general rule or procedure"""
        if category not in self.knowledge_base['rules']:
            self.knowledge_base['rules'][category] = []
        
        self.knowledge_base['rules'][category].append({
            'content': rule,
            'confidence': confidence,
            'created': datetime.now().isoformat(),
            'type': 'rule'
        })
    
    def add_pattern(self, pattern_name: str, description: str, evidence_count: int = 1):
        """Add an observed pattern with evidence strength"""
        if pattern_name in self.knowledge_base['patterns']:
            # Update existing pattern
            self.knowledge_base['patterns'][pattern_name]['evidence_count'] += evidence_count
            self.knowledge_base['patterns'][pattern_name]['confidence'] = min(
                1.0, self.knowledge_base['patterns'][pattern_name]['evidence_count'] * 0.1
            )
        else:
            # Create new pattern
            self.knowledge_base['patterns'][pattern_name] = {
                'description': description,
                'evidence_count': evidence_count,
                'confidence': min(1.0, evidence_count * 0.1),
                'created': datetime.now().isoformat(),
                'type': 'pattern'
            }
    
    def add_fact(self, category: str, fact: str, source: str = "experience"):
        """Add factual knowledge"""
        if category not in self.knowledge_base['facts']:
            self.knowledge_base['facts'][category] = []
        
        self.knowledge_base['facts'][category].append({
            'content': fact,
            'source': source,
            'created': datetime.now().isoformat(),
            'type': 'fact'
        })
    
    def get_relevant_knowledge(self, context: Dict) -> Dict:
        """Retrieve knowledge relevant to current context"""
        relevant = {
            'rules': [],
            'patterns': [],
            'facts': []
        }
        
        # Simple keyword matching - in practice, use semantic similarity
        context_keywords = [str(v).lower() for v in context.values()]
        
        for category, rules in self.knowledge_base['rules'].items():
            for rule in rules:
                if any(keyword in rule['content'].lower() for keyword in context_keywords):
                    relevant['rules'].append(rule)
        
        for pattern_name, pattern in self.knowledge_base['patterns'].items():
            if any(keyword in pattern['description'].lower() for keyword in context_keywords):
                relevant['patterns'].append(pattern)
        
        return relevant
    
    @property
    def memory_variables(self) -> List[str]:
        return [self.memory_key]
    
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        # Format knowledge for agent consumption
        formatted_knowledge = []
        
        # Add high-confidence rules
        for category, rules in self.knowledge_base['rules'].items():
            for rule in rules[-3:]:  # Latest 3 rules per category
                if rule['confidence'] > 0.7:
                    formatted_knowledge.append(f"RULE: {rule['content']}")
        
        # Add strong patterns
        strong_patterns = [
            f"PATTERN: {name} - {info['description']}" 
            for name, info in self.knowledge_base['patterns'].items() 
            if info['confidence'] > 0.5
        ]
        formatted_knowledge.extend(strong_patterns[-5:])  # Latest 5 patterns
        
        return {self.memory_key: "\n".join(formatted_knowledge)}
    
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        # Context saving handled manually through add_* methods
        pass
    
    def clear(self) -> None:
        self.knowledge_base = {
            'rules': {},
            'patterns': {},
            'facts': {},
            'best_practices': {}
        }

# ===============================
# HEALTHCARE DIAGNOSTIC EXAMPLE
# ===============================

print("=== HEALTHCARE DIAGNOSTIC SYSTEM WITH EPISODIC & SEMANTIC MEMORY ===")

# Initialize memory systems
diagnostic_episodic = EpisodicMemory()    # Specific patient cases
diagnostic_semantic = SemanticMemory()    # Medical knowledge

treatment_episodic = EpisodicMemory()     # Treatment outcomes  
treatment_semantic = SemanticMemory()     # Treatment protocols

research_episodic = EpisodicMemory()      # Research experiences
research_semantic = SemanticMemory()      # Research knowledge

# Pre-populate semantic memory with medical knowledge
diagnostic_semantic.add_rule(
    'diagnosis', 
    'Chest pain + shortness of breath + smoker history suggests cardiac evaluation needed',
    confidence=0.9
)

diagnostic_semantic.add_pattern(
    'cardiac_risk_pattern',
    'Patients over 45 with chest pain and smoking history have 70% probability of cardiac issues',
    evidence_count=15  # Based on 15 similar cases
)

treatment_semantic.add_rule(
    'cardiology',
    'Suspected cardiac patients should receive ECG and cardiac enzymes immediately',
    confidence=0.95
)

# ===============================
# AGENTS WITH DUAL MEMORY SYSTEMS
# ===============================

class DualMemoryAgent(Agent):
    """Custom agent that uses both episodic and semantic memory"""
    
    def __init__(self, episodic_memory: EpisodicMemory, semantic_memory: SemanticMemory, **kwargs):
        super().__init__(**kwargs)
        self.episodic_memory = episodic_memory
        self.semantic_memory = semantic_memory
    
    def remember_experience(self, event: str, context: Dict, outcome: str, emotion: str = None):
        """Store a specific experience in episodic memory"""
        self.episodic_memory.add_experience(event, context, outcome, emotion)
        
        # Extract patterns for semantic memory
        self.extract_patterns_from_experience(event, context, outcome)
    
    def extract_patterns_from_experience(self, event: str, context: Dict, outcome: str):
        """Learn general patterns from specific experiences"""
        # Simple pattern extraction - in practice, use ML/NLP
        if 'diagnosis' in event.lower() and 'correct' in outcome.lower():
            pattern_key = f"successful_{context.get('condition', 'unknown')}_diagnosis"
            self.semantic_memory.add_pattern(
                pattern_key,
                f"Successful diagnosis pattern for {context.get('condition', 'condition')}",
                evidence_count=1
            )

# Create agents with dual memory systems
diagnostic_doctor = DualMemoryAgent(
    episodic_memory=diagnostic_episodic,
    semantic_memory=diagnostic_semantic,
    role='Diagnostic Physician',
    goal='Diagnose patients using both past experience and medical knowledge',
    backstory='Experienced doctor who learns from each patient case while applying medical expertise',
    verbose=True
)

treatment_specialist = DualMemoryAgent(
    episodic_memory=treatment_episodic,
    semantic_memory=treatment_semantic,
    role='Treatment Specialist',
    goal='Provide treatment recommendations based on experience and protocols',
    backstory='Treatment expert who combines evidence-based protocols with clinical experience',
    verbose=True
)

research_coordinator = DualMemoryAgent(
    episodic_memory=research_episodic,
    semantic_memory=research_semantic,
    role='Medical Research Coordinator',
    goal='Coordinate research activities using past study experiences and research knowledge',
    backstory='Research expert who learns from each study while maintaining research best practices',
    verbose=True
)

# ===============================
# MEMORY-INFORMED TASKS
# ===============================

def create_memory_informed_task(description: str, agent: DualMemoryAgent, context_data: Dict):
    """Create a task that uses both episodic and semantic memory"""
    
    # Get relevant experiences (episodic)
    similar_experiences = agent.episodic_memory.get_similar_experiences(context_data)
    
    # Get relevant knowledge (semantic) 
    relevant_knowledge = agent.semantic_memory.get_relevant_knowledge(context_data)
    
    # Enhance task description with memory context
    enhanced_description = f"""
    {description}
    
    RELEVANT PAST EXPERIENCES (Episodic Memory):
    {json.dumps(similar_experiences[-3:], indent=2) if similar_experiences else 'No similar experiences found'}
    
    RELEVANT KNOWLEDGE (Semantic Memory):
    {json.dumps(relevant_knowledge, indent=2) if relevant_knowledge else 'No relevant knowledge patterns found'}
    """
    
    return Task(
        description=enhanced_description,
        agent=agent,
        expected_output=f'{agent.role} assessment with memory-informed reasoning'
    )

# Create memory-informed tasks
patient_context = {
    'age': 52,
    'gender': 'male', 
    'symptoms': ['chest_pain', 'shortness_of_breath'],
    'history': ['smoking', 'hypertension'],
    'condition': 'cardiac_evaluation'
}

diagnostic_task = create_memory_informed_task(
    'Evaluate patient with chest pain and shortness of breath',
    diagnostic_doctor,
    patient_context
)

treatment_task = create_memory_informed_task(
    'Recommend treatment plan based on diagnostic findings',
    treatment_specialist,
    patient_context
)

research_task = create_memory_informed_task(
    'Design research study for cardiac patients with similar profiles',
    research_coordinator,
    patient_context
)

# ===============================
# MEMORY LEARNING WORKFLOW
# ===============================

class MemoryLearningWorkflow:
    """Workflow that demonstrates how agents learn and update memories"""
    
    def __init__(self, agents: List[DualMemoryAgent]):
        self.agents = agents
        self.case_history = []
    
    def process_case(self, case_data: Dict):
        """Process a case and update agent memories"""
        
        print(f"\n=== PROCESSING CASE: {case_data.get('case_id', 'Unknown')} ===")
        
        # Simulate case processing
        for agent in self.agents:
            # Agent makes decision using current memory
            decision = self.simulate_agent_decision(agent, case_data)
            
            # Record experience in episodic memory
            agent.remember_experience(
                event=f"Processed {case_data.get('condition', 'case')} case",
                context=case_data,
                outcome=decision['outcome'],
                emotion=decision.get('confidence_level', 'neutral')
            )
            
            # Update semantic memory with learned patterns
            if decision['outcome'] == 'successful':
                agent.semantic_memory.add_rule(
                    category=case_data.get('condition', 'general'),
                    rule=decision['learned_rule'],
                    confidence=decision.get('confidence', 0.8)
                )
        
        self.case_history.append({
            'case_data': case_data,
            'timestamp': datetime.now().isoformat(),
            'agents_involved': [agent.role for agent in self.agents]
        })
    
    def simulate_agent_decision(self, agent: DualMemoryAgent, case_data: Dict) -> Dict:
        """Simulate agent decision-making process"""
        
        # Get memory context
        similar_cases = agent.episodic_memory.get_similar_experiences(case_data)
        relevant_knowledge = agent.semantic_memory.get_relevant_knowledge(case_data)
        
        # Simulate decision logic
        confidence = 0.7
        if similar_cases:
            confidence += 0.2  # Higher confidence with experience
        if relevant_knowledge['patterns']:
            confidence += 0.1  # Higher confidence with knowledge
        
        return {
            'outcome': 'successful' if confidence > 0.8 else 'needs_review',
            'confidence': min(confidence, 1.0),
            'confidence_level': 'high' if confidence > 0.8 else 'moderate',
            'learned_rule': f"For {case_data.get('condition', 'similar')} cases, apply enhanced monitoring protocol",
            'memory_influence': {
                'episodic_cases': len(similar_cases),
                'semantic_patterns': len(relevant_knowledge.get('patterns', []))
            }
        }
    
    def demonstrate_memory_evolution(self):
        """Show how memories evolve over time"""
        
        print("\n=== MEMORY EVOLUTION DEMONSTRATION ===")
        
        # Simulate multiple cases to show learning
        test_cases = [
            {'case_id': 'C001', 'condition': 'cardiac_evaluation', 'age': 45, 'symptoms': ['chest_pain']},
            {'case_id': 'C002', 'condition': 'cardiac_evaluation', 'age': 52, 'symptoms': ['chest_pain', 'dyspnea']},
            {'case_id': 'C003', 'condition': 'cardiac_evaluation', 'age': 48, 'symptoms': ['chest_pain'], 'risk_factors': ['smoking']},
            {'case_id': 'C004', 'condition': 'respiratory_evaluation', 'age': 35, 'symptoms': ['dyspnea']},
            {'case_id': 'C005', 'condition': 'cardiac_evaluation', 'age': 55, 'symptoms': ['chest_pain', 'dyspnea']}
        ]
        
        for case in test_cases:
            self.process_case(case)
        
        # Show memory state evolution
        print("\n=== FINAL MEMORY STATES ===")
        for agent in self.agents:
            print(f"\n{agent.role} Memory Summary:")
            print(f"  Episodic Experiences: {len(agent.episodic_memory.experiences)}")
            print(f"  Semantic Patterns: {len(agent.semantic_memory.knowledge_base['patterns'])}")
            print(f"  Semantic Rules: {sum(len(rules) for rules in agent.semantic_memory.knowledge_base['rules'].values())}")

# ===============================
# CREW WITH DUAL MEMORY SYSTEM
# ===============================

dual_memory_crew = Crew(
    agents=[diagnostic_doctor, treatment_specialist, research_coordinator],
    tasks=[diagnostic_task, treatment_task, research_task],
    process=Process.sequential,
    memory=False,  # Using custom memory systems
    verbose=True
)

# ===============================
# EXECUTION AND DEMONSTRATION
# ===============================

def demonstrate_episodic_semantic_memory():
    """Full demonstration of episodic and semantic memory systems"""
    
    print("=== DUAL MEMORY SYSTEM DEMONSTRATION ===\n")
    
    # Initialize learning workflow
    workflow = MemoryLearningWorkflow([diagnostic_doctor, treatment_specialist, research_coordinator])
    
    # Demonstrate memory evolution
    workflow.demonstrate_memory_evolution()
    
    # Execute main crew task
    print("\n=== EXECUTING MAIN DIAGNOSTIC CREW ===")
    result = dual_memory_crew.kickoff(inputs={
        'patient_data': 'Male, 52 years old, chest pain, shortness of breath, smoking history',
        'urgency_level': 'high',
        'available_resources': 'ECG, cardiac enzymes, chest X-ray'
    })
    
    # Show final memory states
    print("\n=== MEMORY ANALYSIS ===")
    
    for agent in [diagnostic_doctor, treatment_specialist, research_coordinator]:
        print(f"\n{agent.role} Memory Analysis:")
        
        # Episodic memory summary
        recent_experiences = agent.episodic_memory.get_recent_experiences(30)
        print(f"  Recent Experiences (30 days): {len(recent_experiences)}")
        
        if recent_experiences:
            print("  Latest Experience:")
            latest = recent_experiences[-1]
            print(f"    - Event: {latest['event']}")
            print(f"    - Outcome: {latest['outcome']}")
            print(f"    - Timestamp: {latest['timestamp']}")
        
        # Semantic memory summary
        total_patterns = len(agent.semantic_memory.knowledge_base['patterns'])
        total_rules = sum(len(rules) for rules in agent.semantic_memory.knowledge_base['rules'].values())
        print(f"  Learned Patterns: {total_patterns}")
        print(f"  Accumulated Rules: {total_rules}")
        
        if agent.semantic_memory.knowledge_base['patterns']:
            strongest_pattern = max(
                agent.semantic_memory.knowledge_base['patterns'].items(),
                key=lambda x: x[1]['confidence']
            )
            print(f"  Strongest Pattern: {strongest_pattern[0]} (confidence: {strongest_pattern[1]['confidence']:.2f})")
    
    return result

# Execute the demonstration
result = demonstrate_episodic_semantic_memory()

"""
KEY INSIGHTS: EPISODIC vs SEMANTIC MEMORY

EPISODIC MEMORY CHARACTERISTICS:
✓ Stores specific experiences with full context
✓ Includes temporal information (when it happened)
✓ Maintains emotional and situational details
✓ Enables learning from specific past cases
✓ Supports experience-based decision making

SEMANTIC MEMORY CHARACTERISTICS:
✓ Stores general knowledge and abstract concepts
✓ Independent of specific time/context
✓ Accumulates patterns and rules over time
✓ Enables knowledge-based reasoning
✓ Supports generalization across situations

COMBINED BENEFITS:
✓ Richer decision-making using both experience and knowledge
✓ Continuous learning from specific cases (episodic → semantic)
✓ Pattern recognition across multiple experiences
✓ Contextual adaptation based on similar past situations
✓ Knowledge validation through experiential evidence

PRACTICAL APPLICATIONS:
- Medical diagnosis: Remember specific patient cases + general medical knowledge
- Customer service: Recall customer interactions + service protocols  
- Financial analysis: Remember market events + financial principles
- Legal advice: Recall case precedents + legal knowledge
- Engineering: Remember project experiences + technical standards

IMPLEMENTATION CONSIDERATIONS:
- Memory size management (episodic memories can grow large)
- Pattern extraction algorithms (convert episodes to semantic knowledge)
- Memory retrieval efficiency (similarity search, indexing)
- Knowledge confidence tracking (strengthen patterns with evidence)
- Memory consolidation (merge similar experiences, update knowledge)
"""