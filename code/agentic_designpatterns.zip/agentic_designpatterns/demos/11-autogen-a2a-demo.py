import os
import json
from typing import Dict, List, Any, Optional, Callable
import asyncio
from dataclasses import dataclass
import autogen
from autogen import ConversableAgent, AssistantAgent, UserProxyAgent, GroupChat, GroupChatManager
from autogen.agentchat.contrib.web_surfer import WebSurferAgent
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent
import requests

# Set up Azure OpenAI configuration
# You'll need to set these environment variables:
# os.environ["AZURE_OPENAI_API_KEY"] = "your_azure_openai_key"
# os.environ["AZURE_OPENAI_ENDPOINT"] = "https://your-resource.openai.azure.com/"
# os.environ["AZURE_OPENAI_API_VERSION"] = "2024-02-15-preview"

# Azure OpenAI configuration
azure_config = {
    "model": "gpt-4",  # Your deployed model name
    "api_key": os.getenv("AZURE_OPENAI_API_KEY"),
    "base_url": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "api_type": "azure",
    "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
}

@dataclass
class AgentRole:
    """Define agent roles and capabilities"""
    name: str
    role: str
    capabilities: List[str]
    system_message: str
    tools: List[str] = None

class AzureAutoGenA2ADemo:
    """Azure AutoGen Agent-to-Agent demonstration platform"""
    
    def __init__(self):
        self.config_list = [azure_config]
        self.agents = {}
        self.conversations = []
        
    def create_specialized_agents(self) -> Dict[str, ConversableAgent]:
        """Create a suite of specialized agents for A2A collaboration"""
        
        # 1. Data Analyst Agent
        data_analyst = AssistantAgent(
            name="DataAnalyst",
            system_message="""You are a Senior Data Analyst specializing in business intelligence and statistical analysis.
            
            Your capabilities:
            - Analyze datasets and identify patterns
            - Perform statistical calculations
            - Create data visualizations conceptually
            - Interpret business metrics
            - Provide data-driven recommendations
            
            When collaborating with other agents:
            - Ask clarifying questions about data requirements
            - Share your analytical findings clearly
            - Suggest additional analyses that might be valuable
            - Validate assumptions with other domain experts
            
            Always cite your analytical methods and confidence levels.""",
            llm_config={"config_list": self.config_list, "temperature": 0.1}
        )
        
        # 2. Financial Expert Agent
        financial_expert = AssistantAgent(
            name="FinancialExpert", 
            system_message="""You are a Senior Financial Advisor with expertise in corporate finance, investments, and risk management.
            
            Your capabilities:
            - Financial modeling and forecasting
            - Investment analysis and portfolio management
            - Risk assessment and mitigation strategies
            - Market analysis and trend identification
            - Regulatory compliance guidance
            
            When collaborating with other agents:
            - Provide financial context to business decisions
            - Validate financial calculations and assumptions
            - Identify potential financial risks
            - Suggest optimization strategies
            - Ensure regulatory compliance considerations
            
            Always provide reasoning for financial recommendations and include risk assessments.""",
            llm_config={"config_list": self.config_list, "temperature": 0.2}
        )
        
        # 3. Tech Architect Agent
        tech_architect = AssistantAgent(
            name="TechArchitect",
            system_message="""You are a Senior Technical Architect with expertise in cloud architecture, system design, and emerging technologies.
            
            Your capabilities:
            - Design scalable system architectures
            - Evaluate technology stacks and frameworks
            - Assess technical feasibility
            - Identify integration requirements
            - Recommend best practices and standards
            
            When collaborating with other agents:
            - Translate business requirements into technical specifications
            - Identify technical constraints and opportunities
            - Validate implementation approaches
            - Suggest alternative technical solutions
            - Consider scalability, security, and maintenance
            
            Always consider both current needs and future scalability in your recommendations.""",
            llm_config={"config_list": self.config_list, "temperature": 0.3}
        )
        
        # 4. Market Research Agent
        market_researcher = AssistantAgent(
            name="MarketResearcher",
            system_message="""You are a Senior Market Research Analyst specializing in competitive intelligence and market trends.
            
            Your capabilities:
            - Industry and competitive analysis
            - Market sizing and segmentation
            - Consumer behavior analysis
            - Trend identification and forecasting
            - SWOT and competitive positioning
            
            When collaborating with other agents:
            - Provide market context for strategic decisions
            - Validate market assumptions and hypotheses
            - Identify competitive threats and opportunities
            - Share relevant industry benchmarks
            - Suggest go-to-market strategies
            
            Always back your insights with market data and cite information sources when possible.""",
            llm_config={"config_list": self.config_list, "temperature": 0.4}
        )
        
        # 5. Project Manager Agent
        project_manager = AssistantAgent(
            name="ProjectManager",
            system_message="""You are a Senior Project Manager specializing in complex, cross-functional initiatives.
            
            Your capabilities:
            - Project planning and timeline development
            - Resource allocation and management
            - Risk identification and mitigation
            - Stakeholder coordination
            - Quality assurance and delivery
            
            When collaborating with other agents:
            - Facilitate discussions and keep them focused
            - Identify dependencies and potential blockers
            - Ensure all perspectives are considered
            - Synthesize recommendations into actionable plans
            - Track decisions and next steps
            
            Always focus on practical implementation and realistic timelines.""",
            llm_config={"config_list": self.config_list, "temperature": 0.2}
        )
        
        # 6. Quality Assurance Agent
        qa_specialist = AssistantAgent(
            name="QASpecialist",
            system_message="""You are a Senior Quality Assurance Specialist focused on validation, testing, and risk mitigation.
            
            Your capabilities:
            - Validate assumptions and recommendations
            - Identify potential risks and edge cases
            - Design testing and validation strategies
            - Ensure compliance with standards
            - Challenge conclusions constructively
            
            When collaborating with other agents:
            - Ask probing questions to validate assumptions
            - Identify potential failure points
            - Suggest validation methods and success criteria
            - Ensure recommendations are thoroughly vetted
            - Play devil's advocate when necessary
            
            Always focus on quality, reliability, and risk mitigation.""",
            llm_config={"config_list": self.config_list, "temperature": 0.1}
        )
        
        self.agents = {
            "data_analyst": data_analyst,
            "financial_expert": financial_expert, 
            "tech_architect": tech_architect,
            "market_researcher": market_researcher,
            "project_manager": project_manager,
            "qa_specialist": qa_specialist
        }
        
        return self.agents
    
    def create_user_proxy(self) -> UserProxyAgent:
        """Create user proxy agent for human interaction"""
        
        return UserProxyAgent(
            name="User",
            human_input_mode="NEVER",  # Set to "ALWAYS" for interactive mode
            max_consecutive_auto_reply=3,
            is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),
            system_message="""You represent the user/client requesting analysis or consultation.
            You will provide the initial problem statement and can ask follow-up questions.
            When satisfied with the team's recommendations, respond with 'TERMINATE'.""",
            llm_config={"config_list": self.config_list}
        )
    
    def setup_group_chat(self, agents: List[ConversableAgent], 
                        max_round: int = 20) -> GroupChat:
        """Set up group chat for multi-agent collaboration"""
        
        return GroupChat(
            agents=agents,
            messages=[],
            max_round=max_round,
            speaker_selection_method="round_robin",  # or "auto" for dynamic selection
            allow_repeat_speaker=True
        )
    
    def create_custom_group_chat_manager(self, groupchat: GroupChat) -> GroupChatManager:
        """Create enhanced group chat manager with custom logic"""
        
        class CustomGroupChatManager(GroupChatManager):
            def __init__(self, groupchat, **kwargs):
                super().__init__(groupchat, **kwargs)
            
            def select_speaker(self, last_speaker, selector):
                """Custom speaker selection logic"""
                # You can implement custom logic here
                # For now, using default behavior
                return super().select_speaker(last_speaker, selector)
        
        return CustomGroupChatManager(
            groupchat=groupchat,
            llm_config={"config_list": self.config_list},
            system_message="""You are the Group Chat Manager coordinating a team of expert agents.
            
            Your responsibilities:
            - Facilitate productive discussions between agents
            - Ensure all relevant perspectives are heard
            - Keep discussions focused on the objective
            - Synthesize inputs from multiple agents
            - Guide the conversation toward actionable conclusions
            
            Rules:
            - Allow each agent to contribute their expertise
            - Encourage collaboration and knowledge sharing
            - Prevent endless loops or circular discussions
            - Summarize key decisions and recommendations
            - Terminate when a comprehensive solution is reached"""
        )
    
    def run_business_strategy_analysis(self, problem_statement: str) -> str:
        """Run a comprehensive business strategy analysis using A2A collaboration"""
        
        print("🎯 Starting Business Strategy Analysis")
        print("=" * 50)
        print(f"Problem: {problem_statement}")
        print("=" * 50)
        
        # Create agents
        agents = self.create_specialized_agents()
        user_proxy = self.create_user_proxy()
        
        # Create group chat with strategic order
        agent_list = [
            user_proxy,
            agents["project_manager"],  # Facilitator
            agents["market_researcher"], # Context setting
            agents["data_analyst"],     # Data insights
            agents["financial_expert"], # Financial analysis
            agents["tech_architect"],   # Technical feasibility
            agents["qa_specialist"]     # Validation
        ]
        
        groupchat = self.setup_group_chat(agent_list, max_round=25)
        manager = self.create_custom_group_chat_manager(groupchat)
        
        # Start the conversation
        result = user_proxy.initiate_chat(
            manager,
            message=f"""
            Our team needs to analyze this business challenge:
            
            {problem_statement}
            
            Please work together to provide:
            1. Market analysis and competitive landscape
            2. Data-driven insights and recommendations  
            3. Financial implications and projections
            4. Technical implementation considerations
            5. Risk assessment and mitigation strategies
            6. Actionable implementation plan
            
            Each expert should contribute their specialized knowledge, and we should 
            collaborate to reach a comprehensive solution.
            """
        )
        
        return result
    
    def run_technical_architecture_review(self, system_requirements: str) -> str:
        """Run technical architecture review with A2A collaboration"""
        
        print("🏗️ Starting Technical Architecture Review")
        print("=" * 50)
        print(f"Requirements: {system_requirements}")
        print("=" * 50)
        
        agents = self.create_specialized_agents()
        user_proxy = self.create_user_proxy()
        
        # Focus on technical agents for this scenario
        agent_list = [
            user_proxy,
            agents["tech_architect"],   # Lead architect
            agents["data_analyst"],     # Data requirements
            agents["financial_expert"], # Cost analysis
            agents["qa_specialist"],    # Quality & risk
            agents["project_manager"]   # Implementation planning
        ]
        
        groupchat = self.setup_group_chat(agent_list, max_round=20)
        manager = self.create_custom_group_chat_manager(groupchat)
        
        result = user_proxy.initiate_chat(
            manager,
            message=f"""
            We need a comprehensive technical architecture review for:
            
            {system_requirements}
            
            Please collaborate to provide:
            1. Recommended system architecture and technology stack
            2. Data storage and processing requirements
            3. Cost analysis and budget projections
            4. Security and compliance considerations
            5. Performance and scalability planning
            6. Implementation timeline and milestones
            7. Risk assessment and mitigation strategies
            
            Work together to ensure all technical, financial, and quality aspects are covered.
            """
        )
        
        return result
    
    def run_investment_analysis(self, investment_opportunity: str) -> str:
        """Run investment analysis with multi-agent collaboration"""
        
        print("💰 Starting Investment Analysis")
        print("=" * 50)
        print(f"Opportunity: {investment_opportunity}")
        print("=" * 50)
        
        agents = self.create_specialized_agents()
        user_proxy = self.create_user_proxy()
        
        agent_list = [
            user_proxy,
            agents["financial_expert"], # Lead financial analysis
            agents["market_researcher"], # Market opportunity
            agents["data_analyst"],     # Quantitative analysis
            agents["tech_architect"],   # Technical due diligence
            agents["qa_specialist"],    # Risk assessment
            agents["project_manager"]   # Implementation planning
        ]
        
        groupchat = self.setup_group_chat(agent_list, max_round=22)
        manager = self.create_custom_group_chat_manager(groupchat)
        
        result = user_proxy.initiate_chat(
            manager,
            message=f"""
            Please evaluate this investment opportunity:
            
            {investment_opportunity}
            
            Collaborate to provide comprehensive analysis including:
            1. Market opportunity and competitive positioning
            2. Financial projections and ROI analysis
            3. Technical feasibility and requirements
            4. Risk assessment and mitigation strategies
            5. Due diligence recommendations
            6. Investment recommendation with rationale
            
            Each expert should contribute their domain expertise to reach a well-informed decision.
            """
        )
        
        return result
    
    def demonstrate_sequential_handoffs(self):
        """Demonstrate sequential agent handoffs for complex workflows"""
        
        print("🔄 Sequential Agent Handoffs Demo")
        print("=" * 40)
        
        agents = self.create_specialized_agents()
        
        # Step 1: Market Research
        market_analysis = """
        Based on preliminary research, I've identified a growing market opportunity 
        in AI-powered customer service solutions. The market is valued at $15B and 
        growing at 25% annually. Key competitors include Zendesk, Salesforce, and 
        emerging AI startups.
        """
        
        # Step 2: Data Analysis 
        print("📊 Data Analyst receiving market research...")
        data_response = agents["data_analyst"].generate_reply([{
            "role": "user", 
            "content": f"Market Research Results: {market_analysis}\n\nPlease analyze this data and identify key metrics we should track for a new AI customer service platform."
        }])
        
        print(f"Data Analyst Response: {data_response}\n")
        
        # Step 3: Financial Analysis
        print("💼 Financial Expert analyzing market data...")
        financial_response = agents["financial_expert"].generate_reply([{
            "role": "user",
            "content": f"Market Research: {market_analysis}\nData Analysis: {data_response}\n\nPlease provide financial projections and funding requirements for entering this market."
        }])
        
        print(f"Financial Expert Response: {financial_response}\n")
        
        # Step 4: Technical Architecture
        print("🏗️ Tech Architect designing solution...")
        tech_response = agents["tech_architect"].generate_reply([{
            "role": "user", 
            "content": f"Business Context:\n{market_analysis}\n{data_response}\n{financial_response}\n\nPlease design the technical architecture for an AI customer service platform."
        }])
        
        print(f"Tech Architect Response: {tech_response}\n")
        
        return {
            "market_analysis": market_analysis,
            "data_analysis": data_response,
            "financial_analysis": financial_response, 
            "technical_architecture": tech_response
        }
    
    def demonstrate_consensus_building(self):
        """Demonstrate agents reaching consensus on complex decisions"""
        
        print("🤝 Consensus Building Demo")
        print("=" * 30)
        
        agents = self.create_specialized_agents()
        user_proxy = self.create_user_proxy()
        
        # Create a smaller focused group for consensus
        consensus_agents = [
            user_proxy,
            agents["financial_expert"],
            agents["market_researcher"],
            agents["tech_architect"]
        ]
        
        groupchat = GroupChat(
            agents=consensus_agents,
            messages=[],
            max_round=15,
            speaker_selection_method="auto"
        )
        
        manager = GroupChatManager(
            groupchat=groupchat,
            llm_config={"config_list": self.config_list},
            system_message="Facilitate consensus building among the expert agents. Ensure all viewpoints are heard and guide toward a unified recommendation."
        )
        
        result = user_proxy.initiate_chat(
            manager,
            message="""
            We need to reach consensus on whether to build vs buy vs partner for our new AI customer service platform.
            
            Each expert should provide their perspective, challenge other viewpoints respectfully, 
            and work toward a unified recommendation that considers:
            - Financial implications
            - Market positioning 
            - Technical feasibility
            - Risk factors
            
            Let's discuss and reach a decision together.
            """
        )
        
        return result

# Example usage and demonstrations
def run_comprehensive_demos():
    """Run comprehensive AutoGen A2A demonstrations"""
    
    demo = AzureAutoGenA2ADemo()
    
    print("🚀 Azure AutoGen Agent-to-Agent (A2A) Comprehensive Demo")
    print("=" * 60)
    
    # Demo 1: Business Strategy Analysis
    business_problem = """
    Our mid-size software company (200 employees, $50M revenue) is considering 
    entering the AI/ML market. We have strong engineering capabilities but limited 
    AI expertise. The board wants a comprehensive strategy analysis including market 
    opportunity, competitive landscape, required investments, technical feasibility, 
    and 18-month implementation plan.
    """
    
    try:
        print("\n📈 Demo 1: Business Strategy Analysis")
        result1 = demo.run_business_strategy_analysis(business_problem)
        print("✅ Business strategy analysis completed\n")
    except Exception as e:
        print(f"❌ Demo 1 failed: {e}\n")
    
    # Demo 2: Technical Architecture Review
    system_requirements = """
    Design a scalable, cloud-native e-commerce platform that can handle:
    - 1M+ concurrent users during peak periods
    - Real-time inventory management across 50+ warehouses  
    - AI-powered recommendation engine
    - Multi-region deployment with <100ms latency
    - PCI DSS compliance for payment processing
    - Integration with 20+ third-party services
    - Budget constraint: $2M initial development, $500K/month operational
    """
    
    try:
        print("\n🏗️ Demo 2: Technical Architecture Review")
        result2 = demo.run_technical_architecture_review(system_requirements)
        print("✅ Technical architecture review completed\n")
    except Exception as e:
        print(f"❌ Demo 2 failed: {e}\n")
    
    # Demo 3: Investment Analysis
    investment_opportunity = """
    Evaluate acquisition of a Series B AI startup:
    - Company: 'DataMind AI' - predictive analytics platform
    - Revenue: $15M ARR, growing 150% YoY
    - Team: 85 employees, strong tech leadership
    - Asking price: $200M (13.3x revenue multiple)
    - Technology: Proprietary ML algorithms, 50+ enterprise customers
    - Market: $45B TAM in predictive analytics
    - Competition: Palantir, Snowflake, emerging startups
    - Integration timeline: 12-18 months
    """
    
    try:
        print("\n💰 Demo 3: Investment Analysis")  
        result3 = demo.run_investment_analysis(investment_opportunity)
        print("✅ Investment analysis completed\n")
    except Exception as e:
        print(f"❌ Demo 3 failed: {e}\n")
    
    # Demo 4: Sequential Handoffs
    try:
        print("\n🔄 Demo 4: Sequential Agent Handoffs")
        result4 = demo.demonstrate_sequential_handoffs()
        print("✅ Sequential handoffs completed\n")
    except Exception as e:
        print(f"❌ Demo 4 failed: {e}\n")
    
    # Demo 5: Consensus Building
    try:
        print("\n🤝 Demo 5: Consensus Building")
        result5 = demo.demonstrate_consensus_building()
        print("✅ Consensus building completed\n")
    except Exception as e:
        print(f"❌ Demo 5 failed: {e}\n")

def interactive_autogen_session():
    """Run interactive AutoGen A2A session"""
    
    print("🤖 Interactive AutoGen A2A Session")
    print("=" * 40)
    print("Available scenarios:")
    print("1. Business Strategy Analysis")
    print("2. Technical Architecture Review") 
    print("3. Investment Analysis")
    print("4. Custom Multi-Agent Collaboration")
    print("Type 'quit' to exit\n")
    
    demo = AzureAutoGenA2ADemo()
    
    while True:
        choice = input("Select scenario (1-4) or 'quit': ").strip()
        
        if choice.lower() in ['quit', 'exit', 'q']:
            print("👋 Session ended!")
            break
        
        if choice == '1':
            problem = input("Enter business problem: ")
            if problem:
                result = demo.run_business_strategy_analysis(problem)
                print(f"Analysis completed!")
        
        elif choice == '2':
            requirements = input("Enter system requirements: ")
            if requirements:
                result = demo.run_technical_architecture_review(requirements)
                print(f"Architecture review completed!")
        
        elif choice == '3':
            opportunity = input("Enter investment opportunity: ")
            if opportunity:
                result = demo.run_investment_analysis(opportunity)
                print(f"Investment analysis completed!")
        
        elif choice == '4':
            custom_problem = input("Enter custom problem for multi-agent collaboration: ")
            if custom_problem:
                # Use business strategy analysis as template for custom problems
                result = demo.run_business_strategy_analysis(custom_problem)
                print(f"Custom analysis completed!")
        
        else:
            print("Please select 1-4 or 'quit'")
        
        print("\n" + "-" * 40 + "\n")

# AutoGen A2A Key Features Summary
def print_autogen_capabilities():
    """Print AutoGen's key A2A capabilities"""
    
    capabilities = """
    🎯 Azure AutoGen Agent-to-Agent (A2A) Key Capabilities:
    
    **Multi-Agent Conversations:**
    ✅ Simultaneous collaboration between specialized agents
    ✅ Dynamic speaker selection and conversation flow
    ✅ Group chat management with custom logic
    ✅ Sequential and parallel agent workflows
    
    **Agent Specialization:**
    ✅ Role-based agent design with specific expertise
    ✅ Custom system messages and behavior configuration
    ✅ Tool integration and capability enhancement
    ✅ Domain-specific knowledge and reasoning
    
    **Conversation Management:**
    ✅ GroupChat for multi-agent discussions
    ✅ GroupChatManager for conversation orchestration
    ✅ Custom speaker selection algorithms
    ✅ Termination condition management
    
    **Collaboration Patterns:**
    ✅ Consensus building among agents
    ✅ Sequential handoffs for complex workflows
    ✅ Peer review and validation processes
    ✅ Distributed problem-solving approaches
    
    **Advanced Features:**
    ✅ Human-in-the-loop integration
    ✅ Tool calling and function execution
    ✅ Memory and context management
    ✅ Custom agent behaviors and personalities
    
    **Use Cases:**
    ✅ Business strategy development
    ✅ Technical architecture design
    ✅ Investment and financial analysis
    ✅ Research and development projects
    ✅ Quality assurance and validation
    ✅ Complex decision-making scenarios
    
    **Advantages over single-agent systems:**
    - Specialized expertise per domain
    - Reduced bias through diverse perspectives
    - Built-in validation and peer review
    - Scalable to complex multi-step problems
    - Natural conversation flow and collaboration
    """
    
    print(capabilities)

# Main execution
if __name__ == "__main__":
    
    # Print capabilities overview
    print_autogen_capabilities()
    
    # Quick test to verify setup
    try:
        demo = AzureAutoGenA2ADemo()
        agents = demo.create_specialized_agents()
        print(f"\n✅ AutoGen setup successful! Created {len(agents)} specialized agents.")
        print("Agents:", ", ".join(agents.keys()))
    except Exception as e:
        print(f"\n❌ Setup failed: {e}")
        print("Please check your Azure OpenAI configuration.")
    
    # Uncomment to run full demonstrations
    # run_comprehensive_demos()
    
    # Uncomment to run interactive session  
    interactive_autogen_session()