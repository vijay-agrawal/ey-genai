# CrewAI: ReAct vs ReWOO — Fraud Detection (Side-by-Side)

This project demonstrates the SAME task (“detect fraudulent transactions”) solved two ways:
- **ReAct**: single agent interleaves reasoning and tool calls.
- **ReWOO**: planner emits a tool plan → operator executes → finalizer writes.

## Quick Start
```
pip install -r requirements.txt
cp .env.example .env  # add OPENAI_API_KEY (or point OPENAI_API_BASE to a local compatible endpoint)
python run_both.py --pattern both
```
Outputs in `outputs/`:
- `react_trace.jsonl` and `react_report.md`
- `rewoo_steps.jsonl`, `rewoo_evidence.md`, and `rewoo_report.md`
