#!/usr/bin/env python3
import os
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from rich import print
from utils import load_tx, rule_score_tx, log_jsonl

load_dotenv()
MODEL = os.getenv("MODEL_NAME","gpt-4o-mini")
TX_TABLE = rule_score_tx(load_tx()).to_markdown(index=False)

react_agent = Agent(
    role="Fraud Investigator (ReAct)",
    goal="Identify which transactions require review and explain why.",
    backstory="Iteratively: think → consult evidence → think…",
    allow_delegation=False,
    model=MODEL,
)

react_task = Task(
    agent=react_agent,
    description=(
        "REACT LOOP:\n"
        "1) THINK about the next step.\n"
        "2) ACT by consulting exactly one 'tool': the TX TABLE provided below.\n"
        "3) OBSERVE: read the table and update your reasoning.\n"
        "Stop when confident. Then output a markdown report with:\n"
        "- Transactions to REVIEW (tx_id + rationale)\n"
        "- Transactions to ALLOW (tx_id + brief reason)\n"
        "- Portfolio summary: % review, average rule_score (2 decimals)\n"
        "≤150 words."
    ),
    expected_output="Markdown report."
)

crew = Crew(agents=[react_agent], tasks=[react_task], process=Process.sequential)

if __name__ == "__main__":
    react_task.context = [TX_TABLE]
    log_jsonl("outputs/react_trace.jsonl", {"event":"start","pattern":"react"})
    result = crew.kickoff()
    log_jsonl("outputs/react_trace.jsonl", {"event":"end","pattern":"react","result":str(result)[:1500]})
    with open("outputs/react_report.md","w",encoding="utf-8") as f: f.write(str(result))
    print("[bold green]ReAct run complete → outputs/react_report.md[/bold green]")
