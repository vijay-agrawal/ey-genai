#!/usr/bin/env python3
import os
from pydantic import BaseModel, Field
from typing import List, Dict, Any
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from rich import print
from utils import load_tx, rule_score_tx, log_jsonl

load_dotenv()
MODEL = os.getenv("MODEL_NAME","gpt-4o-mini")

class Operation(BaseModel):
    op: str = Field(..., description="e.g. 'score' or 'threshold'")
    args: Dict[str, Any] = Field(default_factory=dict)

class ToolPlan(BaseModel):
    goal: str
    steps: List[Operation]

planner = Agent(
    role="Planner (ReWOO)",
    goal="Write a minimal ToolPlan to detect risky transactions. Do not execute tools.",
    backstory="Auditable planning first.",
    allow_delegation=False,
    model=MODEL
)

operator = Agent(
    role="Operator (ReWOO)",
    goal="Execute the ToolPlan exactly and produce evidence.",
    backstory="Runs local tools only; no speculation.",
    allow_delegation=False,
    model=MODEL
)

finalizer = Agent(
    role="Finalizer (ReWOO)",
    goal="Summarize operator evidence into a concise fraud triage report.",
    backstory="Clear communicator for risk committees.",
    allow_delegation=False,
    model=MODEL
)

plan_task = Task(
    agent=planner,
    description=(
        "Produce a ToolPlan JSON with 1–3 steps.\n"
        "Allowed ops: 'score' (compute rule scores), 'threshold' (mark decision=1 if score>=60).\n"
        "No tool execution; just the plan."
    ),
    expected_output="A valid JSON ToolPlan.",
    output_json=ToolPlan
)

operate_task = Task(
    agent=operator,
    description=(
        "You are given a ToolPlan JSON. Execute steps in order:\n"
        "- 'score' -> run rule_score_tx on data/tx.csv\n"
        "- 'threshold' -> ensure 'decision' column exists\n"
        "Return JSON with per-step summaries and 'evidence' (markdown table)."
    ),
    expected_output="JSON with 'steps' (list) and 'evidence' (markdown table)."
)

final_task = Task(
    agent=finalizer,
    description=(
        "Using ONLY the operator's evidence, produce a markdown report with:\n"
        "- Transactions to REVIEW (tx_id + rationale)\n"
        "- Transactions to ALLOW (tx_id + brief reason)\n"
        "- Portfolio summary: % review, average rule_score (2 decimals)\n"
        "≤150 words."
    ),
    expected_output="Markdown triage report."
)

crew = Crew(agents=[planner, operator, finalizer], tasks=[plan_task, operate_task, final_task], process=Process.sequential)

if __name__ == "__main__":
    df = rule_score_tx(load_tx())
    evidence_md = df.to_markdown(index=False)
    operate_task.context = [evidence_md]
    log_jsonl("outputs/rewoo_steps.jsonl", {"event":"start","pattern":"rewoo"})
    result = crew.kickoff()
    with open("outputs/rewoo_evidence.md","w",encoding="utf-8") as f: f.write(evidence_md)
    with open("outputs/rewoo_report.md","w",encoding="utf-8") as f: f.write(str(result))
    log_jsonl("outputs/rewoo_steps.jsonl", {"event":"end","pattern":"rewoo","result":str(result)[:1500]})
    print("[bold green]ReWOO run complete → outputs/rewoo_report.md[/bold green]")
