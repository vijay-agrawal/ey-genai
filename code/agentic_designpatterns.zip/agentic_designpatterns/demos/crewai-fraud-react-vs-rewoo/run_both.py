#!/usr/bin/env python3
import argparse, subprocess, sys
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pattern", choices=["react","rewoo","both"], default="both")
    args = ap.parse_args()
    if args.pattern in ("react","both"):
        subprocess.run([sys.executable, "react_run.py"], check=False)
    if args.pattern in ("rewoo","both"):
        subprocess.run([sys.executable, "rewoo_run.py"], check=False)
if __name__ == "__main__":
    main()
