import json, os, pandas as pd

LOG_DIR = "outputs"

def ensure_log_dir():
    os.makedirs(LOG_DIR, exist_ok=True)

def log_jsonl(path, record):
    ensure_log_dir()
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

def load_tx():
    return pd.read_csv("data/tx.csv")

def rule_score_tx(df: pd.DataFrame):
    df = df.copy()
    score = 0
    score += (df["amount"] > 1000) * 30
    score += df["country"].isin(["RU","BR"]).astype(int) * 25
    score += (1 - df["device_score"]) * 30
    score += (df["velocity_1h"] >= 5) * 10
    score += (df["is_blacklisted"] == 1) * 40
    df["rule_score"] = score.clip(0,100).round(1)
    df["decision"] = (df["rule_score"] >= 60).astype(int)
    return df[["tx_id","amount","country","device_score","velocity_1h","is_blacklisted","rule_score","decision"]]
