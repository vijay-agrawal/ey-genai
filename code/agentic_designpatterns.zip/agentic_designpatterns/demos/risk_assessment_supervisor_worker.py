# Import required libraries
from crewai import Agent, Task, Crew, Process
from langchain.llms import OpenAI

"""
SUPERVISOR-WORKER PATTERN EXPLANATION:
This pattern follows a hierarchical structure where:
1. One supervisor agent coordinates and delegates work to multiple worker agents
2. Worker agents perform specialized tasks independently
3. The supervisor reviews all outputs and makes final decisions
4. Communication flows top-down (delegation) and bottom-up (reporting)
"""

# ===============================
# AGENT DEFINITIONS
# ===============================

# SUPERVISOR AGENT - The coordinator/manager
risk_supervisor = Agent(
    role='Risk Assessment Supervisor',  # Defines the agent's primary function
    goal='Coordinate credit risk evaluation workflow',  # What the agent aims to achieve
    backstory='Senior risk manager overseeing loan applications',  # Context for decision-making
    verbose=True,  # Enables detailed logging of agent actions
    allow_delegation=True  # KEY: Enables this agent to delegate tasks to worker agents
)

# WORKER AGENT 1 - Specialized in data processing
data_analyst = Agent(
    role='Data Analyst',
    goal='Extract and analyze financial data',
    backstory='Specialist in financial data processing',
    verbose=True,  # No delegation allowed - this is a worker, not supervisor
)

# WORKER AGENT 2 - Specialized in credit evaluation
credit_evaluator = Agent(
    role='Credit Evaluator', 
    goal='Assess creditworthiness based on analysis',
    backstory='Expert in credit scoring models',
    verbose=True,
)

# WORKER AGENT 3 - Specialized in compliance checking
compliance_checker = Agent(
    role='Compliance Officer',
    goal='Ensure regulatory compliance',
    backstory='Specialist in banking regulations',
    verbose=True,
)

# ===============================
# TASK DEFINITIONS
# ===============================

# Each task is assigned to a specific worker agent
# Tasks represent atomic units of work in the workflow

# WORKER TASK 1 - Data extraction and analysis
data_analysis_task = Task(
    description='Analyze applicant financial data: income, expenses, credit history',
    agent=data_analyst,  # Assigned to specialized data analyst
    expected_output='Financial summary report'  # Clear output specification
)

# WORKER TASK 2 - Credit risk assessment
credit_assessment_task = Task(
    description='Calculate credit score and risk level based on financial data',
    agent=credit_evaluator,  # Assigned to credit specialist
    expected_output='Credit risk assessment with score'
)

# WORKER TASK 3 - Regulatory compliance verification
compliance_task = Task(
    description='Verify loan application meets regulatory requirements',
    agent=compliance_checker,  # Assigned to compliance specialist
    expected_output='Compliance verification report'
)

# SUPERVISOR TASK - Final decision making
supervision_task = Task(
    description='Review all assessments and make final loan decision',
    agent=risk_supervisor,  # Assigned to supervisor agent
    expected_output='Final loan approval/rejection decision'
    # Note: This task will automatically receive outputs from worker tasks
)

# ===============================
# CREW CONFIGURATION
# ===============================

# Create the crew with hierarchical process (supervisor pattern)
crew = Crew(
    # Agent hierarchy: supervisor first, then workers
    agents=[risk_supervisor, data_analyst, credit_evaluator, compliance_checker],
    
    # Task sequence: worker tasks first, supervisor task last
    tasks=[data_analysis_task, credit_assessment_task, compliance_task, supervision_task],
    
    # CRITICAL: Process.hierarchical enables supervisor-worker pattern
    process=Process.hierarchical,
    
    # Manager LLM for supervisor decision-making (temperature=0 for consistency)
    manager_llm=OpenAI(temperature=0)
)

# ===============================
# EXECUTION
# ===============================

# Execute the workflow with input data
# The supervisor will automatically coordinate worker agents
result = crew.kickoff(inputs={'applicant_data': 'John Doe, Income: $75k, Credit Score: 720'})

"""
WORKFLOW EXECUTION FLOW:
1. Supervisor receives input and delegates tasks to workers
2. Data Analyst processes financial information
3. Credit Evaluator assesses risk based on processed data
4. Compliance Checker verifies regulatory requirements
5. Supervisor reviews all worker outputs and makes final decision

BENEFITS OF SUPERVISOR-WORKER PATTERN:
- Clear hierarchy and responsibility
- Specialized expertise in each domain
- Centralized decision-making
- Scalable (can add more worker agents)
- Quality control through supervision
"""