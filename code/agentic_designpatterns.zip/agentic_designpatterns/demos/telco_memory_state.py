#!/usr/bin/env python3
import os, json
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from textwrap import dedent

load_dotenv()
MODEL = os.getenv("MODEL_NAME","gpt-4o-mini")
MEM_PATH = "outputs/telco_memory.json"

def mem_get():
    if not os.path.exists(MEM_PATH): return {}
    return json.load(open(MEM_PATH))

def mem_set(obj):
    os.makedirs("outputs", exist_ok=True)
    json.dump(obj, open(MEM_PATH,"w"), indent=2)

support = Agent(
    role="Telco Tier-1 Support Agent",
    goal="Triage tickets, ask for missing info, and persist session memory (MSISDN, region, symptoms).",
    backstory="Focused on fast resolution and consistent context across steps.",
    model=MODEL
)

resolver = Agent(
    role="Network Resolver",
    goal="Map symptoms to probable causes and next actions using historical patterns.",
    backstory="Understands radio, core, and transport domains; proposes checks or workarounds.",
    model=MODEL
)

summarizer = Agent(
    role="Case Summarizer",
    goal="Write a concise case note for the CRM with memory state and decision.",
    backstory="Turns messy chats into crisp CRM updates.",
    model=MODEL
)

task1 = Task(
    description=dedent("""\
    Load prior memory (if any). Ask clarifying questions ONLY if critical fields are missing:
    - msisdn, region, issue, priority
    Then update memory with fields you learned. Output a short triage note.
    """),
    agent=support
)

task2 = Task(
    description=dedent("""\
    Given current memory state, map symptoms to likely domain and propose next steps:
    - Immediate workaround (if any)
    - Checks to run
    - Escalation path
    """),
    agent=resolver
)

task3 = Task(
    description=dedent("""\
    Compose a CRM case note (<=120 words) including:
    - Key fields from memory
    - Actions taken and next steps
    """),
    agent=summarizer
)

crew = Crew(agents=[support, resolver, summarizer], tasks=[task1, task2, task3], process=Process.sequential)

if __name__ == "__main__":
    memory = mem_get()
    # Provide a starter ticket as context to simulate an ongoing conversation
    starter = {"msisdn":"999001","region":"West","issue":"No data","priority":"High"}
    memory.update(starter)
    mem_set(memory)
    task1.context = [json.dumps(memory)]
    result = crew.kickoff()
    # Save the final memory (in real app, you'd parse and update from agent outputs)
    mem_set(memory)
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/telco_memory_state.md","w") as f: f.write(str(result))
    print("=== Telco Memory + State Result ===")
    print(result)
