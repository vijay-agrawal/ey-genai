"""
Token-Optimized Indian Stock Market AI Recommendation System with 3-Agent Chain
==============================================================================

Uses Azure OpenAI with CrewAI agent chaining while minimizing token consumption.
Uses concise prompts and strict token limits to reduce costs.

Requirements:
- pip install crewai
- pip install openai
- pip install langchain-openai
- pip install crewai-tools
- Set environment variables: AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, 
  AZURE_OPENAI_API_VERSION, AZURE_OPENAI_DEPLOYMENT_NAME, SERPER_API_KEY
"""

import os
os.environ["OTEL_SDK_DISABLED"] = "true" 
os.environ["CREWAI_TELEMETRY_OPT_OUT"] = "true"

# Set LiteLLM environment variables for Azure OpenAI
os.environ["AZURE_API_KEY"] = os.getenv("AZURE_OPENAI_API_KEY", "")
os.environ["AZURE_API_BASE"] = os.getenv("AZURE_OPENAI_ENDPOINT", "")
os.environ["AZURE_API_VERSION"] = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
 
from crewai import Agent, Task, Crew, Process
from datetime import datetime
from crewai_tools import SerperDevTool
from langchain_openai import AzureChatOpenAI
from dotenv import load_dotenv

load_dotenv()

def setup_llm():
    """Initialize Azure OpenAI with strict token limits"""
    return AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),  # e.g., "gpt-35-turbo"
        model=f"azure/{os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')}",  # Required for LiteLLM
        temperature=0.1,
        max_tokens=300,  # Very strict limit per response
    )

class OptimizedStockAnalysisSystem:
    def __init__(self):
        self.llm = setup_llm()
        self.search_tool = SerperDevTool()
        
    def create_research_agent(self):
        """Agent 1: Data gathering - keep it concise"""
        return Agent(
            role="Financial Researcher",
            goal="Find key financial data quickly",
            backstory="Indian market researcher focused on essential metrics only.",
            tools=[self.search_tool],
            llm=self.llm,
            verbose=True,
            allow_delegation=False,
            max_iter=1  # Prevent multiple iterations
        )
    
    def create_analysis_agent(self):
        """Agent 2: Data processing - streamlined"""
        return Agent(
            role="Financial Analyst", 
            goal="Analyze data and identify key trends",
            backstory="Analyst specializing in concise Indian stock evaluation.",
            llm=self.llm,
            verbose=True,
            allow_delegation=False,
            max_iter=1
        )
    
    def create_recommendation_agent(self):
        """Agent 3: Final recommendation - brief and actionable"""
        return Agent(
            role="Investment Advisor",
            goal="Provide clear buy/sell recommendation",
            backstory="Investment advisor providing quick, actionable advice.",
            llm=self.llm,
            verbose=True,
            allow_delegation=False,
            max_iter=1
        )
    
    def create_optimized_tasks(self, stock_symbol):
        """Create 3 chained tasks with minimal token usage"""
        
        # Task 1: Research (Agent 1)
        research_task = Task(
            description=f"""
            Find ONLY these key points for {stock_symbol}:
            - Current price and 1-week trend
            - Latest earnings (revenue, profit)
            - One recent news headline
            
            Limit: 100 words maximum.
            """,
            agent=self.create_research_agent(),
            expected_output="Key financial data in 100 words or less"
        )
        
        # Task 2: Analysis (Agent 2) 
        analysis_task = Task(
            description=f"""
            Based on research data, provide:
            - Price trend: UP/DOWN/FLAT
            - Financial health: GOOD/AVERAGE/POOR
            - Market sentiment: POSITIVE/NEUTRAL/NEGATIVE
            
            Limit: 80 words maximum.
            """,
            agent=self.create_analysis_agent(),
            expected_output="Concise analysis in 80 words or less",
            dependencies=[research_task]
        )
        
        # Task 3: Recommendation (Agent 3)
        recommendation_task = Task(
            description=f"""
            Based on analysis, provide:
            - Action: BUY/SELL/HOLD
            - Target price: INR amount
            - Risk: LOW/MEDIUM/HIGH
            - Reason: One sentence only
            
            Limit: 60 words maximum.
            """,
            agent=self.create_recommendation_agent(),
            expected_output="Final recommendation in 60 words or less",
            dependencies=[analysis_task]
        )
        
        return [research_task, analysis_task, recommendation_task]
    
    def analyze_stock(self, stock_symbol):
        """Execute 3-agent chain with minimal tokens"""
        print(f"🔄 3-Agent Chain Analysis: {stock_symbol}")
        
        try:
            # Create agents
            agents = [
                self.create_research_agent(),
                self.create_analysis_agent(), 
                self.create_recommendation_agent()
            ]
            
            # Create tasks
            tasks = self.create_optimized_tasks(stock_symbol)
            
            # Create crew with minimal settings
            crew = Crew(
                agents=agents,
                tasks=tasks,
                process=Process.sequential,
                verbose=True,
                max_rpm=3  # Limit requests per minute
            )
            
            # Execute with strict timeout
            print("📊 Executing agent chain...")
            result = crew.kickoff()
            
            return {
                'symbol': stock_symbol,
                'chain_result': str(result),
                'timestamp': datetime.now().strftime('%H:%M:%S'),
                'agents_used': 3,
                'status': 'success'
            }
            
        except Exception as e:
            return {
                'symbol': stock_symbol,
                'error': str(e)[:150],
                'status': 'error'
            }

def demo_agent_chaining():
    """Demonstrate 3-agent chaining with minimal token usage"""
    
    # Verify API keys
    required_env_vars = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_DEPLOYMENT_NAME",
        "SERPER_API_KEY"
    ]
    
    missing_vars = [var for var in required_env_vars if not os.getenv(var)]
    if missing_vars:
        print(f"❌ Missing environment variables: {', '.join(missing_vars)}")
        print("\nRequired variables:")
        print("  - AZURE_OPENAI_ENDPOINT (e.g., https://your-resource.openai.azure.com/)")
        print("  - AZURE_OPENAI_API_KEY")
        print("  - AZURE_OPENAI_API_VERSION (optional, defaults to 2024-02-15-preview)")
        print("  - AZURE_OPENAI_DEPLOYMENT_NAME (e.g., gpt-35-turbo)")
        print("  - SERPER_API_KEY")
        return
    
    print("🤖 3-Agent Stock Analysis Chain Demo (Azure OpenAI)")
    print("=" * 50)
    print(f"🔧 Config: Azure OpenAI, 300 tokens/response max")
    print(f"🌐 Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
    print(f"📦 Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')}")
    print("⚡ Agent Flow: Research → Analysis → Recommendation")
    print()
    
    # Initialize system
    system = OptimizedStockAnalysisSystem()
    
    # Demo with one stock (add more if needed)
    demo_stocks = ["RELIANCE.NS"]  # Keep minimal for demo
    
    for stock in demo_stocks:
        print(f"📈 Starting 3-agent chain for {stock}...")
        print("-" * 30)
        
        result = system.analyze_stock(stock)
        
        if result['status'] == 'success':
            print(f"✅ Chain completed at {result['timestamp']}")
            print(f"🔗 {result['agents_used']} agents executed sequentially")
            print(f"📋 Final Output:")
            print(f"   {result['chain_result']}")
        else:
            print(f"❌ Chain failed: {result['error']}")
        
        print("\n" + "=" * 50)
    
    print("✅ Agent chaining demonstration complete!")

# Individual agent output viewer (for debugging)
def view_agent_outputs(stock_symbol):
    """See individual agent outputs to understand the chain"""
    system = OptimizedStockAnalysisSystem()
    
    print(f"🔍 Individual Agent Outputs for {stock_symbol}")
    print("=" * 40)
    
    # This would require modifying tasks to capture individual outputs
    # For now, run the full chain
    result = system.analyze_stock(stock_symbol)
    
    if result['status'] == 'success':
        print("🔗 Complete Agent Chain Output:")
        print(result['chain_result'])
    else:
        print(f"❌ Error: {result['error']}")

# Batch processing with agent chaining
def batch_analyze_with_chaining(stock_list):
    """Process multiple stocks through the 3-agent chain"""
    system = OptimizedStockAnalysisSystem()
    results = []
    
    print(f"🚀 Batch processing {len(stock_list)} stocks through 3-agent chain")
    
    for i, stock in enumerate(stock_list, 1):
        print(f"\n[{i}/{len(stock_list)}] Chain processing: {stock}")
        
        result = system.analyze_stock(stock)
        results.append(result)
        
        # Brief delay to manage rate limits
        import time
        time.sleep(3)
    
    return results

if __name__ == "__main__":
    # Run the 3-agent chaining demo
    demo_agent_chaining()
    
    # Optional: View individual agent breakdown
    # view_agent_outputs("TCS.NS")
    
    # Optional: Batch process multiple stocks
    # stocks = ["RELIANCE.NS", "TCS.NS", "HDFCBANK.NS"]
    # batch_results = batch_analyze_with_chaining(stocks)