# KnowledgeGraph Demo

This folder contains code and resources for building and experimenting with knowledge graphs using generative AI and neo4j Graph Database.

## Setup

1. Setup an instance of neo4j Aura (free instance will be fine) and obtain the connection information.
https://console.neo4j.io 

2. You can copy paste the DDL, DML and query cypher examples present in the *.cypher examples into the neo4j query editor and create a knowledge graph in neo4j

3. You can also experiment with the same using neo4j_demo.py and cypher_from_llm.py
Make sure you add the neo4j connection information at the right places in the above python files before running them.




