# MCP Server (Python) Demo Setup

## Python Dependencies

We will use Python, so install the python depenndencies

### Core dependencies

```sh
pip install mcp requests python-dotenv
```

### For LLM integrations

```sh
pip install openai          # For OpenAI GPT models
pip install anthropic       # For Claude models  
pip install "crewai-tools[mcp]" crewai  # For CrewAI integration
```

> **Note:** There's no official Python MCP SDK yet, so we implement JSON-RPC manually.

## Create weather MCP Server

See weather_mcp_server.py for the implementation. It contains a list of tools it exposes and has the implementation for them.
As you will see it exposes 2 tools: get_weather and get_forecast and provides the metadata for them in a standard format.
It also exposes 2 methods that can be called using RPC:
tools/list and tools/call


## Test the MCP Server

Note that there is no http port or anything that the MCP server will listen on
it will be invoked by the client/test as needed using Inter process communication/pipe mechanism

Review and run test_mcp_server.py (or weather_app.py)


## Integrate the tools with any client
The power of standardization with MCP is realized as any client application can now be integrated and out get_weather tool can now be made available to any client that supports MCP, without any coding!

Here we will demonstrate how to integrate it with VS Code and Claude Desktop



Note that there is no http port or anything that the MCP server will listen on
it will be invoked by the client/test as needed using Inter process communication/pipe mechanism

Review and run test_mcp_server.py (or weather_app.py)


