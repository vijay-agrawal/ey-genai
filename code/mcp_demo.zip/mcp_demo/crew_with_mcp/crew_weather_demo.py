import asyncio
import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import MCPServerAdapter

weather_mcp_server_path = "mcp_demo/crew_with_mcp/weather_mcp_server.py"

class WeatherCrewDemo:
    def __init__(self, server_path: str):
        self.server_path = server_path
        
    async def create_weather_crew(self):
        """Create a CrewAI crew with MCP weather tools"""
        
        # Connect to MCP server and get tools
        with MCPServerAdapter(
            server_params={
                "command": "python",
                "args": [self.server_path],
                "transport": "stdio"
            }
        ) as mcp_adapter:
            # Get all weather tools from MCP server
            weather_tools = mcp_adapter.get_tools()
            
            # Create specialized agents
            weather_analyst = Agent(
                role='Weather Data Analyst',
                goal='Gather and analyze current weather conditions and forecasts',
                backstory="""You are an expert meteorological analyst who specializes in 
                interpreting weather data and identifying patterns. You have access to 
                real-time weather information and can provide detailed analysis.""",
                tools=weather_tools,  # MCP tools appear as regular CrewAI tools
                verbose=True
            )
            
            travel_advisor = Agent(
                role='Travel Advisory Specialist', 
                goal='Provide travel recommendations based on weather conditions',
                backstory="""You are a seasoned travel advisor who helps people make 
                informed decisions about their trips based on weather conditions. You 
                consider factors like temperature, precipitation, and seasonal patterns.""",
                tools=weather_tools,  # Same MCP tools, different agent perspective
                verbose=True
            )
            
            activity_planner = Agent(
                role='Activity Planning Expert',
                goal='Suggest appropriate activities based on weather conditions',
                backstory="""You are an outdoor activity expert who recommends the best 
                activities for different weather conditions. You understand how weather 
                impacts various recreational activities.""",
                tools=weather_tools,
                verbose=True
            )
            
            return weather_analyst, travel_advisor, activity_planner
    
    async def run_weather_analysis_crew(self, destination: str):
        """Run a multi-agent weather analysis"""
        
        agents = await self.create_weather_crew()
        weather_analyst, travel_advisor, activity_planner = agents
        
        # Define tasks for each agent
        weather_analysis_task = Task(
            description=f"""Analyze the current weather conditions and 5-day forecast for {destination}.
            Focus on:
            - Current temperature, conditions, and visibility
            - Upcoming weather patterns and changes
            - Any weather warnings or notable conditions
            - Seasonal context and typical patterns
            
            Provide a comprehensive weather analysis report.""",
            agent=weather_analyst,
            expected_output="Detailed weather analysis report with current conditions and forecast"
        )
        
        travel_advisory_task = Task(
            description=f"""Based on the weather analysis, provide travel advice for {destination}.
            Consider:
            - Best days to travel within the forecast period
            - What to pack and clothing recommendations
            - Transportation considerations
            - Weather-related travel tips
            
            Create practical travel recommendations.""",
            agent=travel_advisor,
            context=[weather_analysis_task],  # Uses output from weather analysis
            expected_output="Comprehensive travel advisory with practical recommendations"
        )
        
        activity_planning_task = Task(
            description=f"""Recommend activities for {destination} based on the weather forecast.
            Suggest:
            - Outdoor activities for good weather days
            - Indoor alternatives for poor weather
            - Weather-appropriate activities for each day
            - Equipment or preparation needed
            
            Create a day-by-day activity guide.""",
            agent=activity_planner,
            context=[weather_analysis_task, travel_advisory_task],
            expected_output="Day-by-day activity recommendations based on weather"
        )
        
        # Create and run the crew
        crew = Crew(
            agents=[weather_analyst, travel_advisor, activity_planner],
            tasks=[weather_analysis_task, travel_advisory_task, activity_planning_task],
            process=Process.sequential,  # Run tasks in order
            verbose=2
        )
        
        # Execute the crew
        result = crew.kickoff()
        return result

# Alternative: Multi-destination comparison crew
async def multi_destination_crew_demo():
    """Compare weather across multiple destinations using CrewAI"""
    
    with MCPServerAdapter(
        server_params={
            "command": "python", 
            "args": [weather_mcp_server_path],
            "transport": "stdio"
        }
    ) as mcp_adapter:
        
        # Get specific weather tools
        weather_tools = mcp_adapter.get_tools(['get_weather', 'get_forecast'])
        
        # Create comparison analyst
        comparison_analyst = Agent(
            role='Destination Comparison Expert',
            goal='Compare weather conditions across multiple destinations',
            backstory="""You excel at comparative analysis and help people choose 
            between different travel destinations based on weather patterns.""",
            tools=weather_tools,
            verbose=True
        )
        
        # Multi-destination comparison task
        comparison_task = Task(
            description="""Compare the weather conditions and 5-day forecasts for Tokyo, London, and New York.
            
            For each city, analyze:
            1. Current weather conditions
            2. 5-day forecast trends
            3. Pros and cons for travelers
            4. Best activities for current conditions
            
            Then provide a ranking and recommendation for:
            - Best overall weather
            - Best for outdoor activities  
            - Best for sightseeing
            - Most comfortable conditions
            
            Present findings in a clear comparison format.""",
            agent=comparison_analyst,
            expected_output="Comprehensive weather comparison report with rankings and recommendations"
        )
        
        # Single-agent crew for focused task
        comparison_crew = Crew(
            agents=[comparison_analyst],
            tasks=[comparison_task],
            process=Process.sequential,
            verbose=2
        )
        
        result = comparison_crew.kickoff()
        print("\n" + "="*80)
        print("🌍 MULTI-DESTINATION WEATHER COMPARISON")
        print("="*80)
        print(result)

# Demonstration of CrewAI + MCP integration  
async def demo_crewai_mcp():
    """Demonstrate CrewAI agents using MCP weather tools"""
    
    print("🚀 Starting CrewAI + MCP Weather Demo")
    print("="*50)
    
    demo = WeatherCrewDemo(weather_mcp_server_path)
    
    # Single destination analysis
    destinations = ["Tokyo", "Paris"]
    
    for destination in destinations:
        print(f"\n🌤️ Running weather crew analysis for {destination}")
        print("-" * 50)
        
        try:
            result = await demo.run_weather_analysis_crew(destination)
            print(f"\n✅ Analysis complete for {destination}!")
            print("="*50)
            print(result)
            print("="*50)
            
        except Exception as e:
            print(f"❌ Error analyzing {destination}: {e}")
    
    # Multi-destination comparison
    print(f"\n🌍 Running multi-destination comparison...")
    await multi_destination_crew_demo()

if __name__ == "__main__":
    asyncio.run(demo_crewai_mcp())