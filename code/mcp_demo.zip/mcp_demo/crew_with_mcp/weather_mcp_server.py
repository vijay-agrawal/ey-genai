import asyncio
import json
import sys
import os
import random
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class WeatherMCPServer:
    def __init__(self):
        self.tools = [
            {
                "name": "get_weather",
                "description": "Get current weather information for a city",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "city": {
                            "type": "string",
                            "description": "City name to get weather for"
                        },
                        "units": {
                            "type": "string",
                            "enum": ["metric", "imperial", "kelvin"],
                            "description": "Temperature units",
                            "default": "metric"
                        }
                    },
                    "required": ["city"]
                }
            },
            {
                "name": "get_forecast",
                "description": "Get weather forecast for a city",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "city": {
                            "type": "string",
                            "description": "City name to get forecast for"
                        },
                        "days": {
                            "type": "integer",
                            "description": "Number of days (1-5)",
                            "minimum": 1,
                            "maximum": 5,
                            "default": 3
                        }
                    },
                    "required": ["city"]
                }
            }
        ]
    
    def get_weather(self, city: str, units: str = "metric") -> Dict[str, Any]:
        """Get current weather for a city"""
        api_key = os.getenv('OPENWEATHERMAP_API_KEY', 'demo_key')
        
        if api_key == 'demo_key':
            # Return mock data for demo
            return {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps({
                            "city": city,
                            "temperature": "22°C",
                            "condition": "Partly cloudy",
                            "humidity": "65%",
                            "wind_speed": "10 km/h",
                            "note": "This is mock data. Add OPENWEATHER_API_KEY to .env for real data."
                        }, indent=2)
                    }
                ]
            }
        
        try:
            url = f"http://api.openweathermap.org/data/2.5/weather"
            params = {
                'q': city,
                'appid': api_key,
                'units': units
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            unit_symbol = '°C' if units == 'metric' else ('°F' if units == 'imperial' else 'K')
            speed_unit = 'm/s' if units == 'metric' else 'mph'
            
            weather_data = {
                "city": data['name'],
                "country": data['sys']['country'],
                "temperature": f"{data['main']['temp']}{unit_symbol}",
                "condition": data['weather'][0]['description'],
                "humidity": f"{data['main']['humidity']}%",
                "wind_speed": f"{data['wind']['speed']} {speed_unit}",
                "pressure": f"{data['main']['pressure']} hPa"
            }
            
            return {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(weather_data, indent=2)
                    }
                ]
            }
            
        except requests.exceptions.RequestException as e:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"Error fetching weather data: {str(e)}"
                    }
                ]
            }
    
    def get_forecast(self, city: str, days: int = 3) -> Dict[str, Any]:
        """Get weather forecast for a city"""
        # Generate mock forecast data for demo
        forecasts = []
        conditions = ['Sunny', 'Cloudy', 'Rainy', 'Partly Cloudy', 'Snowy']
        
        for i in range(days):
            forecast_date = datetime.now() + timedelta(days=i)
            forecasts.append({
                "date": forecast_date.strftime("%Y-%m-%d"),
                "high": random.randint(15, 30),
                "low": random.randint(5, 15),
                "condition": random.choice(conditions)
            })
        
        forecast_data = {
            "city": city,
            "forecast": forecasts,
            "note": "This is mock forecast data for demonstration."
        }
        
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps(forecast_data, indent=2)
                }
            ]
        }
    
    async def handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Handle incoming JSON-RPC request"""
        method = request.get('method')
        params = request.get('params', {})
        request_id = request.get('id')
        
        try:
            if method == 'tools/list':
                result = {"tools": self.tools}
                
            elif method == 'tools/call':
                tool_name = params.get('name')
                arguments = params.get('arguments', {})
                
                if tool_name == 'get_weather':
                    result = self.get_weather(
                        arguments.get('city'),
                        arguments.get('units', 'metric')
                    )
                elif tool_name == 'get_forecast':
                    result = self.get_forecast(
                        arguments.get('city'),
                        arguments.get('days', 3)
                    )
                else:
                    raise ValueError(f"Unknown tool: {tool_name}")
            elif method == 'initialize':
                result = {
                    "protocolVersion": "2025-03-26",
                    "serverInfo": {"name": "Weather MCP (Py)", "version": "0.1.0"},
                    "capabilities": {
                        "tools": {}  # you only expose tools; add prompts/resources if you later support them
                    }
                }
                # Send the required notification after responding
                # NOTE: We print the notification here; it's a JSON-RPC *notification* (no "id")
                print(json.dumps({
                    "jsonrpc": "2.0",
                    "method": "notifications/initialized",
                    "params": {}
                }), flush=True)
            else:
                raise ValueError(f"Unknown method: {method}")
            
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": result
            }
            
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32000,
                    "message": str(e)
                }
            }
    
    async def run(self):
        """Run the MCP server"""
        print("Weather MCP Server (Python) running on stdio", file=sys.stderr)
        
        try:
            while True:
                # Read line from stdin with better error handling
                try:
                    line = await asyncio.get_event_loop().run_in_executor(
                        None, sys.stdin.readline
                    )
                    
                    # Check for EOF or empty input
                    if not line or line.strip() == "":
                        break
                    
                    # Parse JSON-RPC request
                    request = json.loads(line.strip())
                    
                    # Handle request
                    response = await self.handle_request(request)
                    
                    # Send response
                    print(json.dumps(response), flush=True)
                    
                except json.JSONDecodeError as e:
                    # Only send error if we actually got input
                    if line and line.strip():
                        error_response = {
                            "jsonrpc": "2.0",
                            "id": None,
                            "error": {
                                "code": -32700,
                                "message": f"Parse error: {str(e)}"
                            }
                        }
                        print(json.dumps(error_response), flush=True)
                    
                except EOFError:
                    break
                    
        except KeyboardInterrupt:
            pass
        except Exception as e:
            print(f"Server error: {e}", file=sys.stderr)

async def main():
    server = WeatherMCPServer()
    await server.run()

if __name__ == "__main__":
    asyncio.run(main())