import asyncio
import json
import os
from typing import List, Dict, Any
from openai import AsyncOpenAI  # or from anthropic import AsyncAnthropic
from mcp_demo.weather_mcpserver_adapter import WeatherMCPServerAdapter

class WeatherAIAgent:
    """An AI agent that uses MCP tools to answer weather questions intelligently"""
    
    def __init__(self, api_key: str, model: str = "gpt-4"):
        self.client = AsyncOpenAI(api_key=api_key)
        self.mcp_client = WeatherMCPServerAdapter()
        self.model = model
        self.conversation_history = []
        
    async def start(self):
        """Initialize the MCP connection"""
        await self.mcp_client.start_server()
        await asyncio.sleep(1)  # Wait for server to start
        print("🤖 Weather AI Agent initialized with MCP tools")
        
    async def get_available_functions(self) -> List[Dict]:
        """Convert MCP tools to OpenAI function calling format"""
        tools = await self.mcp_client.list_tools()
        functions = []
        
        for tool in tools:
            functions.append({
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": tool["inputSchema"]
                }
            })
            
        return functions
    
    async def execute_tool_call(self, tool_call) -> str:
        """Execute MCP tool and return result"""
        function_name = tool_call.function.name
        function_args = json.loads(tool_call.function.arguments)
        
        print(f"🔧 Executing: {function_name}({function_args})")
        
        if function_name == "get_weather":
            result = await self.mcp_client.get_weather(**function_args)
        elif function_name == "get_forecast":
            result = await self.mcp_client.get_forecast(**function_args)
        else:
            result = f"Error: Unknown function {function_name}"
        
        return result
    
    async def chat(self, user_message: str) -> str:
        """Main chat interface with agentic tool usage"""
        
        # Add user message to conversation
        self.conversation_history.append({
            "role": "user", 
            "content": user_message
        })
        
        # Get available tools
        tools = await self.get_available_functions()
        
        # System prompt that makes the AI agentic
        system_message = {
            "role": "system",
            "content": """You are a helpful weather AI agent with access to real-time weather tools.

IMPORTANT CAPABILITIES:
- Use get_weather() for current conditions in any city
- Use get_forecast() for multi-day weather predictions
- Combine multiple tool calls if the user asks about multiple cities
- Provide actionable advice based on weather data (clothing, activities, travel tips)

BEHAVIORAL INSTRUCTIONS:
- Always use tools when weather information is requested
- Be proactive - if someone asks about outdoor activities, check the weather first
- Combine data from multiple cities when doing comparisons
- Give practical, context-aware advice
- If weather data seems outdated, mention it

Be conversational, helpful, and intelligent in your responses."""
        }
        
        messages = [system_message] + self.conversation_history
        
        try:
            # First API call - let the LLM decide if it needs tools
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=tools,
                tool_choice="auto",  # Let the model decide
                temperature=0.7
            )
            
            response_message = response.choices[0].message
            
            # Handle tool calls if any
            if response_message.tool_calls:
                # Add the assistant's message (with tool calls) to history
                self.conversation_history.append({
                    "role": "assistant",
                    "content": response_message.content,
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": tc.type,
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments
                            }
                        } for tc in response_message.tool_calls
                    ]
                })
                
                # Execute each tool call
                for tool_call in response_message.tool_calls:
                    tool_result = await self.execute_tool_call(tool_call)
                    
                    # Add tool result to conversation
                    self.conversation_history.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": tool_result
                    })
                
                # Get final response with tool results
                final_response = await self.client.chat.completions.create(
                    model=self.model,
                    messages=[system_message] + self.conversation_history,
                    temperature=0.7
                )
                
                final_content = final_response.choices[0].message.content
                self.conversation_history.append({
                    "role": "assistant",
                    "content": final_content
                })
                
                return final_content
                
            else:
                # No tools needed, just return the response
                self.conversation_history.append({
                    "role": "assistant",
                    "content": response_message.content
                })
                return response_message.content
                
        except Exception as e:
            error_msg = f"Sorry, I encountered an error: {str(e)}"
            self.conversation_history.append({
                "role": "assistant",
                "content": error_msg
            })
            return error_msg
    
    async def close(self):
        """Clean shutdown"""
        await self.mcp_client.close()
