import asyncio
import os
from mcp_demo.weather_agent_with_mcp_tools import WeatherAIAgent

from dotenv import load_dotenv

load_dotenv()

# Example usage demonstrating agentic behavior
async def demo_ai_agent():
    """Demonstrate the AI agent's agentic capabilities"""
    
    # Initialize agent (you'll need an OpenAI API key)
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        print("❌ Please set OPENAI_API_KEY environment variable")
        return
    
    agent = WeatherAIAgent(api_key)
    
    try:
        await agent.start()
        
        # Demonstrate various agentic behaviors
        test_queries = [
            # Simple weather query
            "What's the weather like in London?",
            
            # Multi-city comparison (agent should call multiple tools)
            "I'm deciding between visiting Paris or Rome this weekend. Which has better weather?",
            
            # Context-aware advice (agent should check weather then give advice)
            "I'm planning a picnic tomorrow in Tokyo. Any suggestions?",
            
            # Forecast-based planning
            "What should I pack for a 5-day trip to New York?",
            
            # Follow-up questions (testing conversation memory)
            "What about the weekend forecast there?"
        ]
        
        for i, query in enumerate(test_queries, 1):
            print(f"\n{'='*60}")
            print(f"🧪 Test {i}: {query}")
            print(f"{'='*60}")
            
            response = await agent.chat(query)
            print(f"🤖 Agent: {response}")
            
            # Add delay between requests
            await asyncio.sleep(1)
            
        print(f"\n{'='*60}")
        print("✅ Agentic AI demo completed!")
        print("Notice how the AI:")
        print("- Automatically used weather tools when needed")
        print("- Made multiple tool calls for comparisons") 
        print("- Provided contextual advice based on weather")
        print("- Maintained conversation context")
        print(f"{'='*60}")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
    finally:
        await agent.close()

# Run the agentic demo
if __name__ == "__main__":
    asyncio.run(demo_ai_agent())