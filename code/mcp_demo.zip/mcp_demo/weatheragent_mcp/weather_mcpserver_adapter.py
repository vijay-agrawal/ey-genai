import asyncio
import json
import subprocess
import sys
from typing import Dict, Any, List
import os
from pathlib import Path

class WeatherMCPServerAdapter:
    def __init__(self, server_path: str):
        self.server_path = server_path
        self.process = None
        
    async def start_server(self):
        """Start the MCP server process"""
        # Use the same Python interpreter that's running this script
        python_exe = sys.executable

        try:
            
            self.process = await asyncio.create_subprocess_exec(
                python_exe, 
                'weather_mcp_server.py',
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            print("✅ MCP Weather server started")
        except Exception as e:
            print(f"❌ Failed to start server: {e}")
            return False
        return True
    
    async def send_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Send a JSON-RPC request to the MCP server"""
        if not self.process:
            raise Exception("Server not started")
            
        request_json = json.dumps(request) + '\n'
        
        # Send request
        self.process.stdin.write(request_json.encode())
        await self.process.stdin.drain()
        
        # Read response
        response_line = await self.process.stdout.readline()
        response = json.loads(response_line.decode().strip())
        
        return response
    
    async def list_tools(self) -> List[Dict[str, Any]]:
        """List available tools from the MCP server"""
        request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/list"
        }
        
        response = await self.send_request(request)
        return response.get('result', {}).get('tools', [])
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """Call a specific tool with arguments"""
        request = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments
            }
        }
        
        response = await self.send_request(request)
        return response.get('result', {})
    
    async def get_weather(self, city: str, units: str = 'metric') -> str:
        """Get current weather for a city"""
        result = await self.call_tool('get_weather', {'city': city, 'units': units})
        
        if result and 'content' in result:
            return result['content'][0]['text']
        return "No weather data available"
    
    async def get_forecast(self, city: str, days: int = 3) -> str:
        """Get weather forecast for a city"""
        result = await self.call_tool('get_forecast', {'city': city, 'days': days})
        
        if result and 'content' in result:
            return result['content'][0]['text']
        return "No forecast data available"
    
    async def close(self):
        """Close the MCP server connection"""
        if self.process:
            self.process.terminate()
            await self.process.wait()
            print("🔌 MCP server connection closed")

async def demo_weather_client():
    """Demonstrate the MCP weather client"""    
    client = WeatherMCPServerAdapter(server_path='weather_mcp_server.py')
    
    try:
        # Start the MCP server
        await client.start_server()
        
        # Give server time to start
        await asyncio.sleep(1)
        
        # List available tools
        print("\n🔧 Available Tools:")
        tools = await client.list_tools()
        for tool in tools:
            print(f"  - {tool['name']}: {tool['description']}")
        
        print("\n" + "="*50)
        
        # Demo weather queries
        cities = ['London', 'New York', 'Tokyo']
        
        for city in cities:
            print(f"\n🌤️  Weather for {city}:")
            weather_data = await client.get_weather(city)
            weather_json = json.loads(weather_data)
            
            print(f"   Temperature: {weather_json['temperature']}")
            print(f"   Condition: {weather_json['condition']}")
            print(f"   Humidity: {weather_json['humidity']}")
            
            print(f"\n📅 3-Day Forecast for {city}:")
            forecast_data = await client.get_forecast(city, 3)
            forecast_json = json.loads(forecast_data)
            
            for day in forecast_json['forecast']:
                print(f"   {day['date']}: {day['high']}°C/{day['low']}°C - {day['condition']}")
        
        print("\n" + "="*50)
        print("✅ Demo completed successfully!")
        
    except Exception as e:
        print(f"❌ Error during demo: {e}")
    finally:
        await client.close()

if __name__ == "__main__":
    asyncio.run(demo_weather_client())