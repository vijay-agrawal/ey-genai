# Import os to handle environment variables
#
# To run this app
# 
# streamlit run <path to this file, for example, rag\streamlit_app_basic.py>
#
import os
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI

load_dotenv()

st.subheader("<Your Name>'s AI chatbot")

def generate_response(input_text):
        
        # 1. Access Gen AI Model from AWS Bedrock service
        # 2. Pass the user text to the AWS Bedrock API 
        # 3. Get the response from the Gen AI Model
        # 4. Print it on the output
        client = AzureOpenAI(
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                api_version=os.getenv("AZURE_OPENAI_API_VERSION")
        )
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME")

        try:
                response = client.chat.completions.create(
                model=model_name,
                messages=[
                        {"role": "system", "content": 
                        """ You are a helpful AI assistant which answers questions about cricket and sports in general.
                            Do not answer questions about other topics. 
                            If you do not know the answer, say 'I do not know the answer to that question.'
                        """
                        },
                        {"role": "user", "content": input_text}
                ] )
                #print (response)
                answer = response.choices[0].message.content.strip()
        except Exception as e:
                print(e) # Log error and continue
        st.info(answer)  # Display the response content

user_question = st.text_input("Ask any question. Press enter to submit", key="user_question")
if user_question:
    generate_response(user_question)