#### Steps to run this project
1. Run the indexer.py from your project root directory.This will read the hdfc_financial_statement_2024.pdf, chunk it, create embeddings and save them in the vector database<br>Hint: If indexer.py is not in project root, modify the path of the pdf file in indexer.py (line 57)
2. Make sure chroma_db file is created in your project roort directory. It contains the embeddings from the HDFC financial report
3. Run retriever.py to test it.
4. Run streamlit_app_rag_pdf_qanda.py by issuing following command:
```bash
streamlit run streamlit_rag_app.py
```
5. You can ask any question about the document, such as "who will be a good fit for accountant role?"
