import os
from langchain_openai import AzureOpenAIEmbeddings
import warnings
from dotenv import load_dotenv
import glob

load_dotenv()
warnings.filterwarnings("ignore")

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db")

def load_document(file):
    name, extension = os.path.splitext(file)

    if extension == '.pdf':
        from langchain_community.document_loaders import PyPDFLoader
        print(f'Loading {file}')
        loader = PyPDFLoader(file)
    elif extension == '.docx':
        from langchain_community.document_loaders import Docx2txtLoader
        print(f'Loading {file}')
        loader = Docx2txtLoader(file)
    elif extension == '.txt':
        from langchain_community.document_loaders import TextLoader
        loader = TextLoader(file)
    else:
        print('Document format is not supported!')
        return None

    data = loader.load()
    return data

def chunk_data(data, chunk_size=256):
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=20  # Added some overlap
    )
    chunks = text_splitter.split_documents(data)
    print(f"Created {len(chunks)} chunks")
    return chunks 

def create_embeddings_chroma(chunks, persist_directory=CHROMA_PATH):
    from langchain_community.vectorstores import Chroma
 
    # Load credentials from environment
    embeddings = AzureOpenAIEmbeddings(
        model="text-embedding-ada-002",
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_KEY"),
        api_version=os.getenv("AZURE_OPENAI_EMBEDDING_API_VERSION"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
    )

    try:
        Chroma.from_documents(chunks, embeddings, persist_directory=persist_directory)
        print("Successfully created Chroma vector store")
    except Exception as e:
        print(f"Error creating embeddings: {e}")
        raise

#### MAIN PROCESSING STARTS HERE

data_dir = os.path.join(os.getcwd(), 'ragdemo/data')
pdf_files = glob.glob(os.path.join(data_dir, '*.pdf'))

# Load all PDF documents - flatten the structure
all_documents = []  # Renamed for clarity
for pdf_file in pdf_files:
    try:
        print(f'Processing file: {pdf_file}')
        docs = load_document(pdf_file)
        if docs:
            all_documents.extend(docs)  # Use extend instead of append
            print(f"Loaded: {os.path.basename(pdf_file)}")
    except Exception as e:
        print(f"Error loading {pdf_file}: {e}")

if not all_documents:
    print("No documents loaded successfully!")
    exit(1)

print(f'Loaded {len(all_documents)} document pages...')

# Split the documents into chunks
print('Splitting documents into chunks')
chunks = chunk_data(all_documents, chunk_size=256)

if chunks:
    create_embeddings_chroma(chunks)
    print('Chroma vector db created successfully')
else:
    print('No chunks created - check your documents')