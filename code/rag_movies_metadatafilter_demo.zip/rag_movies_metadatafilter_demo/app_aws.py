import os
import time
import streamlit as st
from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from langchain_aws import BedrockEmbeddings, ChatBedrock
from langchain.prompts import PromptTemplate
import boto3

# Validate AWS credentials
if not all([os.getenv("AWS_REGION"), os.getenv("AWS_ACCESS_KEY_ID"), os.getenv("AWS_SECRET_ACCESS_KEY")]):
    st.error("AWS credentials are not set properly. Please configure AWS_REGION, AWS_ACCESS_KEY_ID, and AWS_SECRET_ACCESS_KEY.")
    st.stop()

# Set AWS credentials from environment variables
bedrock_runtime = boto3.client(
    service_name="bedrock-runtime",
    region_name=os.getenv("AWS_REGION"),
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY")
)

# Expanded Bollywood movies dataset (replace with actual dataset loading)
movies_data = [
    {"title": "Sholay", "genre": "Action", "year": 1975, "director": "Ramesh Sippy", "plot": "Two criminals, Jai and Veeru, are hired by a retired police officer to fight off a notorious bandit, Gabbar Singh."},
    {"title": "Anand", "genre": "Comedy", "year": 1971, "director": "Hrishikesh Mukherjee", "plot": "A terminally ill man spreads joy and positivity to those around him."},
    {"title": "Gol Maal", "genre": "Comedy", "year": 1979, "director": "Hrishikesh Mukherjee", "plot": "A man lies about his identity to secure a job, leading to hilarious misunderstandings."},
    {"title": "Don", "genre": "Action", "year": 1978, "director": "Chandra Barot", "plot": "A police officer recruits a lookalike to infiltrate a criminal gang."},
    {"title": "Chupke Chupke", "genre": "Comedy", "year": 1975, "director": "Hrishikesh Mukherjee", "plot": "A newlywed couple plays pranks to test their family’s wit."},
    {"title": "Deewaar", "genre": "Action", "year": 1975, "director": "Yash Chopra", "plot": "Two brothers take different paths—one becomes a cop, the other a criminal."},
    {"title": "Pakeezah", "genre": "Romance", "year": 1972, "director": "Kamal Amrohi", "plot": "A courtesan’s tragic love story unfolds in a world of societal constraints."},
    {"title": "Mughal-e-Azam", "genre": "Drama", "year": 1960, "director": "K. Asif", "plot": "A prince’s forbidden love for a courtesan leads to conflict with his emperor father."},
    {"title": "Amar Akbar Anthony", "genre": "Comedy", "year": 1977, "director": "Manmohan Desai", "plot": "Three brothers, separated at birth, reunite to fight a common enemy."},
    {"title": "Zanjeer", "genre": "Action", "year": 1973, "director": "Prakash Mehra", "plot": "An honest police officer seeks justice against a powerful criminal."},
    {"title": "Mother India", "genre": "Drama", "year": 1957, "director": "Mehboob Khan", "plot": "A mother struggles to raise her sons amidst poverty and moral dilemmas."},
    {"title": "Bobby", "genre": "Romance", "year": 1973, "director": "Raj Kapoor", "plot": "A teenage love story defies class and family expectations."},
    {"title": "Namak Halaal", "genre": "Comedy", "year": 1982, "director": "Prakash Mehra", "plot": "A loyal servant protects his employer’s family with wit and bravery."},
    {"title": "Kabhie Kabhie", "genre": "Romance", "year": 1976, "director": "Yash Chopra", "plot": "A poet’s love is tested by separation and family obligations."},
    {"title": "Awara", "genre": "Drama", "year": 1951, "director": "Raj Kapoor", "plot": "A young man’s life of crime is shaped by his troubled upbringing."},
]

# Convert movies to LangChain Documents
def create_documents(data):
    documents = []
    for movie in data:
        doc = Document(
            page_content=f"{movie['title']}: {movie['plot']}",
            metadata={
                "title": movie["title"],
                "genre": movie["genre"],
                "year": movie["year"],
                "director": movie["director"]
            }
        )
        documents.append(doc)
    return documents

# Initialize Bedrock embeddings and LLM
try:
    embedding_model = BedrockEmbeddings(client=bedrock_runtime, model_id="amazon.titan-embed-text-v1")
    llm = ChatBedrock(
        client=bedrock_runtime,
        model_id="anthropic.claude-3-5-sonnet-20240620-v1:0",
        model_kwargs={"max_tokens": 500, "temperature": 0.7}
    )
except Exception as e:
    st.error(f"Failed to initialize Bedrock models: {str(e)}")
    st.stop()

# Initialize ChromaDB
@st.cache_resource
def setup_vectorstore():
    try:
        documents = create_documents(movies_data)
        vectorstore = Chroma.from_documents(
            documents=documents,
            embedding=embedding_model,
            collection_name="bollywood_movies",
            persist_directory="./chroma_db"
        )
        return vectorstore
    except Exception as e:
        st.error(f"Failed to initialize Chroma vectorstore: {str(e)}")
        st.stop()

# Detect metadata filters from query
def detect_filters(query):
    query = query.lower()
    filters = {}
    
    # Genre detection
    genres = ["action", "comedy", "drama", "romance", "thriller"]
    for genre in genres:
        if genre in query:
            filters["genre"] = genre.capitalize()
    
    # Decade detection (e.g., 1970s)
    decades = ["1950s", "1960s", "1970s", "1980s", "1990s", "2000s"]
    for decade in decades:
        if decade in query:
            start_year = int(decade[:4])
            filters["year"] = {"$gte": start_year, "$lte": start_year + 9}
    
    # Director detection
    if "directed by" in query:
        director_name = query.split("directed by")[-1].strip()
        filters["director"] = director_name.title()
    
    # Specific movie title detection (e.g., "about Sholay")
    if "about" in query:
        for movie in movies_data:
            if movie["title"].lower() in query:
                filters["title"] = movie["title"]
    
    return filters

# Process query and generate response
def process_query(query, vectorstore):
    try:
        # Without metadata filter
        start_time = time.time()
        docs_unfiltered = vectorstore.similarity_search(query, k=5)
        unfiltered_time = time.time() - start_time
        
        # With metadata filter
        filters = detect_filters(query)
        start_time = time.time()
        if filters:
            docs_filtered = vectorstore.similarity_search(query, k=5, filter=filters)
        else:
            docs_filtered = docs_unfiltered
        filtered_time = time.time() - start_time
        
        # Prepare context for LLM
        context = "\n".join([f"Title: {doc.metadata['title']}\nGenre: {doc.metadata['genre']}\nYear: {doc.metadata['year']}\nDirector: {doc.metadata['director']}\nPlot: {doc.page_content.split(': ')[1]}" for doc in docs_filtered])
        
        # Define prompt
        prompt_template = PromptTemplate(
            input_variables=["context", "query"],
            template="Based on the following movie information:\n{context}\n\nAnswer the query: {query}"
        )
        prompt = prompt_template.format(context=context, query=query)
        
        # Generate response
        response = llm.invoke(prompt).content
        
        return response, unfiltered_time, filtered_time, docs_filtered
    except Exception as e:
        return f"Error processing query: {str(e)}", 0, 0, []

# Initialize session state for chat history
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Streamlit UI
st.title("Bollywood Movies RAG System")
st.write("Ask about Bollywood movies (e.g., 'What are some good action movies?', 'Tell me about Sholay', 'Comedy movies from the 1970s', 'Movies directed by Hrishikesh Mukherjee')")

# Initialize vectorstore
vectorstore = setup_vectorstore()

# Display chat history
st.subheader("Chat History")
chat_container = st.container()
with chat_container:
    for i, (q, r, ut, ft, docs) in enumerate(st.session_state.chat_history):
        with st.expander(f"Query {i+1}: {q}"):
            st.write(f"**Response**: {r}")
            st.write(f"**Retrieval Times**:")
            st.write(f"- Without metadata filter: {ut:.4f} seconds")
            st.write(f"- With metadata filter: {ft:.4f} seconds")
            st.write("**Retrieved Movies**:")
            for doc in docs:
                st.write(f"- **Title**: {doc.metadata['title']}")
                st.write(f"  **Genre**: {doc.metadata['genre']}")
                st.write(f"  **Year**: {doc.metadata['year']}")
                st.write(f"  **Director**: {doc.metadata['director']}")
                st.write(f"  **Plot**: {doc.page_content.split(': ')[1]}")

# Query input
with st.form(key="query_form", clear_on_submit=True):
    query = st.text_input("Enter your query:", key="query_input")
    submit_button = st.form_submit_button("Submit")

if submit_button and query:
    with st.spinner("Processing..."):
        response, unfiltered_time, filtered_time, docs = process_query(query, vectorstore)
    
    # Append to chat history
    st.session_state.chat_history.append((query, response, unfiltered_time, filtered_time, docs))
    
    # Refresh the page to update chat history
    st.rerun()

# Clear chat history button
if st.button("Clear Chat History"):
    st.session_state.chat_history = []
    st.rerun()